const fs = require('fs');

// ファイルを読み込む
let content = fs.readFileSync('tadjs-desktop.js', 'utf8');

// 1. 残りのif (this.parentMessageBus) { ... } パターンを削除
// メソッド呼び出しの前のifを削除
content = content.replace(/(\s+)if \(this\.parentMessageBus\) \{\s*\n/g, '$1');

// 2. 閉じ括弧のみの行で、その次がelseの場合は削除
content = content.replace(/^\s*\}\s*\n\s*\} else \{/gm, '');

// 3. 単独の閉じ括弧で不要なものを削除（慎重に）
// content = content.replace(/^\s*\}\s*$/gm, '');

// ファイルに書き込む
fs.writeFileSync('tadjs-desktop.js', content, 'utf8');

console.log('残りの修正完了');
