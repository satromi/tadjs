/**
 * フォルダアイコン（.ico）を生成するスクリプト
 * 32x32サイズのシンプルなフォルダアイコンを作成します
 */

const fs = require('fs');
const path = require('path');

// 32x32のフォルダアイコンPNGデータ（Base64エンコード済み）
// シンプルな黄色いフォルダのアイコン
const folderIconPngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAA' +
    'AXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFfSURBVHgB7ZbBUcMwEEVXJqcMuAFKoAS4AZJA' +
    'CZRAByRdQAehBEqgA0qAAjyZg2fEyEbGMhgNM+DhzczaGst69VdaSwYAAAAAAAAAAPwJXJN1VdaV' +
    'dFWCQepDvSv7mvpY6lPzN+tLeQ9lX0t9Kfta+ljqU/M3+0t5D2X/pCwJAAAAAAAAwH+AG7KupKsS' +
    'DFIf6l3Z19THUp+av1lfynso+1rqS9nX0sdSn5q/2V/Keyj7J2VJAAAAAAAAgP8AN2RdSVclGKQ+' +
    '1Luyr6mPpT41f7O+lPdQ9rXUl7KvpY+lPjV/s7+U91D2T8qSAAAAAAAA4Bzukayrcq8Eg9SHelfy' +
    'NfWx1Kfmb9aX8h7Kvpb6Uva19LHUp+Zv9pfyHsr+SVkSAAAAAAAAAOcc1mRdlXslGKQ+1LuSr6mP' +
    'pT41f7O+lPdQ9rXUl7KvpY+lPjV/s7+U91D2T8qSAAAAAAAAAADwn/ABZqxH3UPzCdMAAAAASUVO' +
    'RK5CYII=';

// PNGデータをBufferに変換
const pngBuffer = Buffer.from(folderIconPngBase64, 'base64');

// .ico形式のヘッダーを作成
// ICO形式: [ICONDIR][ICONDIRENTRY][PNG data]
function createIcoFile(pngData) {
    const pngSize = pngData.length;

    // ICONDIRヘッダー (6 bytes)
    const iconDir = Buffer.alloc(6);
    iconDir.writeUInt16LE(0, 0);      // Reserved (must be 0)
    iconDir.writeUInt16LE(1, 2);      // Image type (1 = ICO)
    iconDir.writeUInt16LE(1, 4);      // Number of images

    // ICONDIRENTRYヘッダー (16 bytes)
    const iconDirEntry = Buffer.alloc(16);
    iconDirEntry.writeUInt8(32, 0);   // Width (32 pixels)
    iconDirEntry.writeUInt8(32, 1);   // Height (32 pixels)
    iconDirEntry.writeUInt8(0, 2);    // Color palette (0 = no palette)
    iconDirEntry.writeUInt8(0, 3);    // Reserved (must be 0)
    iconDirEntry.writeUInt16LE(1, 4); // Color planes
    iconDirEntry.writeUInt16LE(32, 6);// Bits per pixel
    iconDirEntry.writeUInt32LE(pngSize, 8);  // Size of image data
    iconDirEntry.writeUInt32LE(22, 12);      // Offset to image data (6 + 16 = 22)

    // すべてのパーツを結合
    return Buffer.concat([iconDir, iconDirEntry, pngData]);
}

// .icoファイルを生成
const icoData = createIcoFile(pngBuffer);

// 保存先パス
const outputPath = path.join(__dirname, 'plugins', 'virtual-object-list', '0199ce60-532a-7670-b8bc-84c970de11dc.ico');

// ファイルに保存
fs.writeFileSync(outputPath, icoData);

console.log('✓ フォルダアイコンを作成しました:', outputPath);
console.log('  サイズ: 32x32 pixels');
console.log('  形式: .ico (ICONフォーマット)');
