/**
 * postpackage.js - パッケージング後のファイルコピー処理
 * クロスプラットフォーム対応のNode.jsスクリプト
 */

const fs = require('fs');
const path = require('path');

const DIST_DIR = path.join(__dirname, '..', 'dist', 'TADjs Desktop-win32-x64');
const DATA_DIR = path.join(DIST_DIR, 'data');
const RESOURCES_APP_DIR = path.join(DIST_DIR, 'resources', 'app');
const XTADDATA_DIR = path.join(__dirname, '..', 'xtaddata');
const ROOT_DIR = path.join(__dirname, '..');

// コピーするルートファイル（distルートへ）
const ROOT_FILES = [
    '019ab620-1e6a-7d17-9598-bccfe61293e0.json',
    '019ab620-1e6a-7d17-9598-bccfe61293e0.ico',
    '019ab620-1e6a-7d17-9598-bccfe61293e0_0.xtad'
];

// コピーするリソースファイル（resources/appへ）
const RESOURCE_FILES = [
    'encoding.js',
    'encoding.min.js',
    'tad.js'
];

// xtaddataからコピーする拡張子
const XTADDATA_EXTENSIONS = ['.json', '.xtad', '.ico', '.png'];

function ensureDir(dir) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log(`Created directory: ${dir}`);
    }
}

function copyFile(src, dest) {
    try {
        fs.copyFileSync(src, dest);
        console.log(`Copied: ${path.basename(src)} -> ${dest}`);
        return true;
    } catch (err) {
        console.error(`Failed to copy ${src}: ${err.message}`);
        return false;
    }
}

function copyFilesWithExtensions(srcDir, destDir, extensions) {
    const files = fs.readdirSync(srcDir);
    let copied = 0;
    let failed = 0;

    for (const file of files) {
        const ext = path.extname(file).toLowerCase();
        if (extensions.includes(ext)) {
            const src = path.join(srcDir, file);
            const dest = path.join(destDir, file);
            if (copyFile(src, dest)) {
                copied++;
            } else {
                failed++;
            }
        }
    }

    return { copied, failed };
}

function main() {
    console.log('=== postpackage: ファイルコピー開始 ===\n');

    // 1. distディレクトリの存在確認
    if (!fs.existsSync(DIST_DIR)) {
        console.error(`Error: dist directory not found: ${DIST_DIR}`);
        process.exit(1);
    }

    // 2. ルートファイルをdistルートへコピー
    console.log('--- ルートファイルをコピー ---');
    for (const file of ROOT_FILES) {
        const src = path.join(ROOT_DIR, file);
        const dest = path.join(DIST_DIR, file);
        if (fs.existsSync(src)) {
            copyFile(src, dest);
        } else {
            console.warn(`Warning: File not found: ${src}`);
        }
    }

    // 3. リソースファイルをresources/appへコピー
    console.log('\n--- リソースファイルをコピー ---');
    ensureDir(RESOURCES_APP_DIR);
    for (const file of RESOURCE_FILES) {
        const src = path.join(ROOT_DIR, file);
        const dest = path.join(RESOURCES_APP_DIR, file);
        if (fs.existsSync(src)) {
            copyFile(src, dest);
        } else {
            console.warn(`Warning: File not found: ${src}`);
        }
    }

    // 4. xtaddataフォルダの内容をdataフォルダへコピー
    console.log('\n--- xtaddataファイルをコピー ---');
    if (fs.existsSync(XTADDATA_DIR)) {
        ensureDir(DATA_DIR);
        const result = copyFilesWithExtensions(XTADDATA_DIR, DATA_DIR, XTADDATA_EXTENSIONS);
        console.log(`\nxtaddata: ${result.copied} files copied, ${result.failed} failed`);
    } else {
        console.warn(`Warning: xtaddata directory not found: ${XTADDATA_DIR}`);
    }

    // 5. nulファイルの削除（Windows環境でのゴミファイル対策）
    console.log('\n--- nulファイルを削除 ---');
    const nulFiles = [
        path.join(ROOT_DIR, 'nul'),
        path.join(RESOURCES_APP_DIR, 'nul')
    ];
    for (const nulFile of nulFiles) {
        if (fs.existsSync(nulFile)) {
            try {
                fs.unlinkSync(nulFile);
                console.log(`Deleted: ${nulFile}`);
            } catch (err) {
                console.error(`Failed to delete ${nulFile}: ${err.message}`);
            }
        }
    }

    console.log('\n=== postpackage: 完了 ===');
}

main();
