/**
 * font-list ライブラリのパッチスクリプト
 * 中国語ロケール ('zh-cn') を日本語ロケール ('ja-jp') に変更
 */

const fs = require('fs');
const path = require('path');

const targetFile = path.join(__dirname, '..', 'node_modules', 'font-list', 'libs', 'win32', 'getByPowerShell.js');

console.log('[Patch] font-list パッチを適用中...');
console.log('[Patch] 対象ファイル:', targetFile);

// ファイルが存在するか確認
if (!fs.existsSync(targetFile)) {
    console.log('[Patch] font-list がインストールされていません。スキップします。');
    process.exit(0);
}

// ファイルを読み込む
let content = fs.readFileSync(targetFile, 'utf8');

// 既にパッチ済みかチェック
if (content.includes("GetLanguage('ja-jp')")) {
    console.log('[Patch] 既にパッチ適用済みです。');
    process.exit(0);
}

// 中国語ロケールを日本語ロケールに置換
const originalPattern1 = "GetLanguage('zh-cn')";
const replacement1 = "GetLanguage('ja-jp')";

if (!content.includes(originalPattern1)) {
    console.log('[Patch] 警告: パッチ対象の文字列が見つかりませんでした。');
    console.log('[Patch] font-list のバージョンが変更された可能性があります。');
    process.exit(1);
}

// 置換実行
content = content.replace(new RegExp(originalPattern1, 'g'), replacement1);

// ファイルに書き込む
fs.writeFileSync(targetFile, content, 'utf8');

console.log('[Patch] パッチ適用完了: zh-cn → ja-jp');
console.log('[Patch] 日本語フォント名が取得できるようになりました。');
