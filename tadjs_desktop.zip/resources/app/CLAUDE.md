# CLAUDE.md

このファイルは、このリポジトリ内のコードを扱う際にClaude Code（claude.ai/code）へのガイドラインを提供します。

## プロジェクト概要

TAD.jsは、BTRONのTAD（Text And Draw）形式ファイル用のJavaScriptベースのドキュメント参照・編集ツールです。テキストとグラフィックスを含むこれらの文書を、モダンなブラウザやElectronベースのアプリで表示できるウェブベースのツールを提供します。

## 最上位ルール

- 効率を最大化するために、**複数の独立したプロセスを実行する必要がある場合は、それらのツールを逐次ではなく並行して呼び出すこと**。  
- **必ず英語で思考すること**。ただし、**日本語で応答すること**。  

- 質問には説明で答えること（こちらが了承するまで勝手に修正しない）  
- こちらが指示した仕様を守ること、こちらが提示した仕様の解釈結果を提示すること  
  - こちらの意図を反映しているか確認すること  
  - こちらの意図と解釈結果が同じか比較すること  
- 実装前に、既存の類似機能を確認すること
- 既存コードの実装パターンを踏襲すること

## 開発用コマンド

### テストの実行
```bash
# HTML インターフェースのテスト
# test-standalone.html をブラウザで開いて UI テスト
# test.html を開いて基本機能のテスト

# Node.js テスト
node test-node.js
node test-file-processing.js
node test-bpk.js

# 圧縮モジュールのテスト（js/ ディレクトリ内）
cd js && npm test


## Electron アプリ開発
Electron アプリをビルドする際には、以下のコマンドを使用してください。

こちらが明示的に指示しない限り、以下のコマンドでビルドだけを行い、絶対にビルド後に exe を実行しないでください。

```
npm run package
```


### Development Server
No build system required - uses ES6 modules directly. Simply serve files with any HTTP server:
```bash
python -m http.server 8000
# or
npx http-server
```

## アーキテクチャ

### モジュール構造 (v0.02 - リファクタ済み)
- **tad.js**: v0.01 API 用のレガシー互換ラッパー

### 主要な設計パターン
1. **クラスベースのアーキテクチャ**: 各モジュールは特定の責務を持つクラスをエクスポートする
2. **ES6 モジュール**: バンドルを行わないモダンなモジュールシステム
3. **Canvas rendering**: すべてのビジュアル出力は HTML5 Canvas API を通じて行う
4. **Event-driven**: ファイル読み込みはドラッグ＆ドロップまたはファイル入力イベントで行う
5. **Segment-based parsing**: TAD ファイルは一連のセグメントとして解析される

### ファイル形式サポート
- `.tad`, `.TAD`: 標準的な TAD 文書ファイル
- `.bpk`, `.BPK`: 複数ファイルを含むアーカイブ形式、圧縮TADを格納
  - 圧縮TAD: 内部的にLH5圧縮をサポート
- 文字コード: TRONコードおよびJIS X 0208

## テスト手法

1. ブラウザテスト: test-standalone.html を使用してインタラクティブにテスト
2. Node.js テスト: test-*.js ファイルを実行して特定機能をテスト
3. サンプルファイル: tad_data/ ディレクトリ内のファイルでテスト
4. デバッグモード: TADViewer オプションで debugMode を有効化し詳細ログを出力

## Common Development Tasks

### Adding New Segment Handler
```javascript
// In TADParser.js
createSegmentHandlers() {
    return {
        [TAD_CONSTANTS.YOUR_SEGMENT]: this.handleYourSegment.bind(this),
        // 既存のハンドラ
    };
}

handleYourSegment(segLen, tadSeg) {
    // Implementation
}
```

### TADファイルの問題をデバッグ
```javascript
const viewer = new TADViewer({
    canvasId: 'canvas',
    debugMode: true  // 詳細なコンソールログを有効化
});
```

## 重要な注意事項

- 従来型のビルドプロセスは不要 - ES6モジュールを直接使用
- 文字コードは重要 - TADはTRON文字コードを使用
- Canvasの座標系はTAD仕様に準拠
- エラーハンドリングでは可能な限り部分的な文書表示を維持すること
- アーカイブ展開は .bpkファイルに対してメモリ内で行われる