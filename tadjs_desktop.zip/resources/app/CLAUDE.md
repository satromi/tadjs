# CLAUDE.md

このファイルは、このリポジトリ内のコードを扱う際にClaude Code (claude.ai/code) へのガイドラインを提供します。

## プロジェクト概要

TADjs Desktopは、BTRONのTAD (Text And Draw) 形式ファイル用のElectronベースのドキュメント参照・編集アプリケーションです。BTRONの特徴である実身/仮身構造を再現し、TADファイル(.tad)およびBPK書庫ファイル(.bpk)の表示・編集が可能です。

### 主要コンポーネント

- **Electronアプリ**: `electron/main.js` (メインプロセス) と `tadjs-desktop.js` (レンダラープロセス)
- **TADエンジン**: `tad.js` - TADファイルのパース・レンダリング
- **プラグインシステム**: `plugins/` - 拡張可能なプラグインアーキテクチャ
- **実身仮身システム**: `js/real-object-system.js` - BTRON風の文書管理
- **メッセージバス**: `js/message-bus.js` - ウィンドウ間・プラグイン間通信

## 最上位ルール

- 効率を最大化するために、**複数の独立したプロセスを実行する必要がある場合は、それらのツールを逐次ではなく並行して呼び出すこと**
- **必ず英語で思考すること**。ただし、**日本語で応答すること**
- 質問には説明で答えること (こちらが了承するまで勝手に修正しない)
- こちらが指示した仕様を守ること、こちらが提示した仕様の解釈結果を提示すること
  - こちらの意図を反映しているか確認すること
  - こちらの意図と解釈結果が同じか比較すること
- 実装前に、既存の類似機能を確認すること
- 既存コードの実装パターンを踏襲すること

## 開発用コマンド

### Electron アプリ開発

```bash
# 開発モードで起動
npm run start

# 開発モード (--devフラグ付き)
npm run dev

# パッケージング (実行ファイル生成)
npm run package

# electron-builderでビルド
npm run build

# Windows用ビルド
npm run build:win
```

**重要**: こちらが明示的に指示しない限り、ビルドだけを行い、絶対にビルド後に exe を実行しないでください。

### ブラウザ版開発 (レガシー)

従来型のビルドプロセスは不要 - ES6モジュールを直接使用:

```bash
# 任意のHTTPサーバーで起動
python -m http.server 8000
# または
npx http-server
```

## アーキテクチャ

### ディレクトリ構造

```
btron-desktop/
├── electron/              # Electronメインプロセス
│   ├── main.js           # アプリケーションエントリーポイント
│   ├── preload.js        # プリロードスクリプト
│   └── plugin-manager.js # (未使用 - レンダラーに移行済み)
├── plugins/              # プラグインディレクトリ
│   ├── basic-text-editor/
│   ├── basic-figure-editor/
│   ├── virtual-object-list/
│   └── ...
├── js/                   # 共通ユーティリティ
│   ├── real-object-system.js
│   ├── virtual-object-renderer.js
│   ├── message-bus.js
│   └── ...
├── tadjs-desktop.js      # メインレンダラープロセス
├── tad.js               # TADパーサー/レンダラー
├── lh5.js               # LH5アーカイブ解凍
└── encoding.js          # TRON文字コード変換
```

### プラグインシステム

プラグインはiframe内で動作するHTML/JavaScriptアプリケーションです。各プラグインは`plugin.json`マニフェストを持ち、親ウィンドウとpostMessageで通信します。

**プラグインタイプ**:
- `base`: 原紙プラグイン (原紙箱に表示可能)
- `accessory`: 小物プラグイン (システム設定など)
- `genko`: 原稿プラグイン (文書表示)
- `viewer`: ビューアプラグイン (仮身一覧など)
- `utility`: ユーティリティプラグイン

詳細は [pluginBuildGuide.md](pluginBuildGuide.md) を参照。

### 実身/仮身システム

BTRONの実身/仮身構造を再現:
- **実身 (Real Object)**: 実際のデータを持つオブジェクト (.json + _0.xtad + .ico)
- **仮身 (Virtual Object)**: 実身への参照
- リンクレコードによるハイパーリンク構造

## 重要な注意事項

### 文字コーディング
- TADはTRON文字コードを使用
- `encoding.js` でShift_JIS、JIS、UTF-8などに対応
- TRON外字の扱いに注意

### Canvas座標系
- TAD仕様に準拠した座標系
- ポイント単位とピクセル単位の変換 (`js/util.js` の `convertPtToPx`)

### エラーハンドリング
- 可能な限り部分的な文書表示を維持
- TADパースエラー時も既存データは表示

### ファイル処理
- .tad: 単一TADファイル
- .bpk: LH5圧縮された書庫 (複数TADを含む可能性)
- アーカイブ展開はメモリ内で実行 (`lh5.js`)

### フォント処理
- `postinstall`スクリプトで`font-list`ライブラリにパッチ適用 (日本語フォント名対応)
- `fontkit`で実際のフォントファイル読み込み
- Windows レジストリからフォント情報取得

## プラグイン開発

新規プラグインを作成する際は:

1. `plugins/your-plugin/` ディレクトリを作成
2. `plugin.json` でメタデータ定義
3. `index.html` をエントリーポイントとして作成
4. 親ウィンドウとのpostMessage通信を実装

**必須メッセージハンドリング**:
- `init`: プラグイン初期化時
- `menu-action`: メニュー選択時
- `get-menu-definition`: メニュー定義要求時

詳細は `pluginBuildGuide.md` および既存プラグイン (`plugins/basic-text-editor/`, `plugins/virtual-object-list/`) を参照。

## コーディング規約

### ES6モジュール
- Webコード (js/以下) はES6モジュールとして記述
- ビルドツール不要 (直接ブラウザで実行可能)

### メッセージ通信
- プラグイン ↔ 親ウィンドウ: `postMessage`
- ウィンドウ間: `MessageBus` クラス (`js/message-bus.js`)

### ログ出力
- プレフィックス付きログ: `console.log('[PluginName] メッセージ')`

## トラブルシューティング

### プラグインが読み込まれない
- `plugin.json` の存在確認
- JSON構文エラーチェック
- コンソールログでエラー確認

### フォントが正しく表示されない
- `npm run postinstall` でパッチ適用確認
- システムフォント一覧取得の動作確認

### ビルド後のexeが起動しない
- `dist/` 内のリソースファイル配置確認
- `postpackage` スクリプトの実行確認
