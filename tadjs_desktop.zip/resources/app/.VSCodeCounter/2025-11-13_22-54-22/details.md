# Details

Date : 2025-11-13 22:54:22

Directory c:\\btron-desktop

Total : 350 files,  338441 codes, 34663 comments, 57687 blanks, all 430791 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.claude/settings.local.json](/.claude/settings.local.json) | JSON | 35 | 0 | 1 | 36 |
| [.eslintrc.json](/.eslintrc.json) | JSON with Comments | 28 | 0 | 0 | 28 |
| [CLAUDE.md](/CLAUDE.md) | Markdown | 84 | 0 | 28 | 112 |
| [README.md](/README.md) | Markdown | 110 | 0 | 46 | 156 |
| [README\_ELECTRON.md](/README_ELECTRON.md) | Markdown | 138 | 0 | 48 | 186 |
| [USER\_MANUAL.md](/USER_MANUAL.md) | Markdown | 479 | 0 | 152 | 631 |
| [claudecode\_tadjsプロンプト.md](/claudecode_tadjs%E3%83%97%E3%83%AD%E3%83%B3%E3%83%97%E3%83%88.md) | Markdown | 948 | 0 | 290 | 1,238 |
| [clean-current-dist.ps1](/clean-current-dist.ps1) | PowerShell | 19 | 3 | 6 | 28 |
| [clean-dist.ps1](/clean-dist.ps1) | PowerShell | 16 | 1 | 3 | 20 |
| [create-folder-icon.js](/create-folder-icon.js) | JavaScript | 35 | 15 | 12 | 62 |
| [delete-nul-files.ps1](/delete-nul-files.ps1) | PowerShell | 18 | 1 | 3 | 22 |
| [delete-old-dist.ps1](/delete-old-dist.ps1) | PowerShell | 16 | 3 | 5 | 24 |
| [dist/TADjs Desktop-win32-x64/0199ce83-6e83-7d42-8962-d2ad8c721654.json](/dist/TADjs%20Desktop-win32-x64/0199ce83-6e83-7d42-8962-d2ad8c721654.json) | JSON | 49 | 0 | 0 | 49 |
| [dist/TADjs Desktop-win32-x64/019a4370-3819-79a2-9758-881e1e0de90a.json](/dist/TADjs%20Desktop-win32-x64/019a4370-3819-79a2-9758-881e1e0de90a.json) | JSON | 43 | 0 | 1 | 44 |
| [dist/TADjs Desktop-win32-x64/019a6c96-e262-7dfd-a3bc-1e85d495d60d.json](/dist/TADjs%20Desktop-win32-x64/019a6c96-e262-7dfd-a3bc-1e85d495d60d.json) | JSON | 43 | 0 | 0 | 43 |
| [dist/TADjs Desktop-win32-x64/019a6c9a-fbc2-76c1-b965-4ac1f7e4dcb7.json](/dist/TADjs%20Desktop-win32-x64/019a6c9a-fbc2-76c1-b965-4ac1f7e4dcb7.json) | JSON | 43 | 0 | 0 | 43 |
| [dist/TADjs Desktop-win32-x64/019a6c9b-e67e-7a35-a461-0d199550e4cf.json](/dist/TADjs%20Desktop-win32-x64/019a6c9b-e67e-7a35-a461-0d199550e4cf.json) | JSON | 43 | 0 | 0 | 43 |
| [dist/TADjs Desktop-win32-x64/LICENSES.chromium.html](/dist/TADjs%20Desktop-win32-x64/LICENSES.chromium.html) | HTML | 120,419 | 0 | 26,708 | 147,127 |
| [dist/TADjs Desktop-win32-x64/encoding.js](/dist/TADjs%20Desktop-win32-x64/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [dist/TADjs Desktop-win32-x64/encoding.min.js](/dist/TADjs%20Desktop-win32-x64/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [dist/TADjs Desktop-win32-x64/f22289dc-a180-494c-a918-f856ea61b404.json](/dist/TADjs%20Desktop-win32-x64/f22289dc-a180-494c-a918-f856ea61b404.json) | JSON | 42 | 0 | 0 | 42 |
| [dist/TADjs Desktop-win32-x64/resources/app/.eslintrc.json](/dist/TADjs%20Desktop-win32-x64/resources/app/.eslintrc.json) | JSON with Comments | 28 | 0 | 0 | 28 |
| [dist/TADjs Desktop-win32-x64/resources/app/CLAUDE.md](/dist/TADjs%20Desktop-win32-x64/resources/app/CLAUDE.md) | Markdown | 84 | 0 | 28 | 112 |
| [dist/TADjs Desktop-win32-x64/resources/app/README.md](/dist/TADjs%20Desktop-win32-x64/resources/app/README.md) | Markdown | 110 | 0 | 46 | 156 |
| [dist/TADjs Desktop-win32-x64/resources/app/README\_ELECTRON.md](/dist/TADjs%20Desktop-win32-x64/resources/app/README_ELECTRON.md) | Markdown | 138 | 0 | 48 | 186 |
| [dist/TADjs Desktop-win32-x64/resources/app/USER\_MANUAL.md](/dist/TADjs%20Desktop-win32-x64/resources/app/USER_MANUAL.md) | Markdown | 479 | 0 | 152 | 631 |
| [dist/TADjs Desktop-win32-x64/resources/app/claudecode\_tadjsプロンプト.md](/dist/TADjs%20Desktop-win32-x64/resources/app/claudecode_tadjs%E3%83%97%E3%83%AD%E3%83%B3%E3%83%97%E3%83%88.md) | Markdown | 948 | 0 | 290 | 1,238 |
| [dist/TADjs Desktop-win32-x64/resources/app/create-folder-icon.js](/dist/TADjs%20Desktop-win32-x64/resources/app/create-folder-icon.js) | JavaScript | 35 | 15 | 12 | 62 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/README.md](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/README.md) | Markdown | 23 | 0 | 12 | 35 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/ecl.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/ecl.js) | JavaScript | 185 | 5 | 21 | 211 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/ecl\_2004.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/ecl_2004.js) | JavaScript | 192 | 92 | 6 | 290 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/ecl\_2004.min.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/ecl_2004.min.js) | JavaScript | 12 | 0 | 1 | 13 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/ecl\_array.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/ecl_array.js) | JavaScript | 592 | 423 | 7 | 1,022 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/ecl\_array.min.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/ecl_array.min.js) | JavaScript | 30 | 0 | 1 | 31 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/encoding.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/encoding.js) | JavaScript | 3,925 | 434 | 61 | 4,420 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/encodingtest.html](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/encodingtest.html) | HTML | 532 | 22 | 40 | 594 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/inflate.min.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/inflate.min.js) | JavaScript | 16 | 0 | 1 | 17 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/text-encoding/LICENSE.md](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/text-encoding/LICENSE.md) | Markdown | 169 | 0 | 34 | 203 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/text-encoding/lib/encoding-indexes.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/text-encoding/lib/encoding-indexes.js) | JavaScript | 38 | 14 | 3 | 55 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/text-encoding/lib/encoding.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/text-encoding/lib/encoding.js) | JavaScript | 1,846 | 451 | 138 | 2,435 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/utils.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/utils.js) | JavaScript | 299 | 35 | 12 | 346 |
| [dist/TADjs Desktop-win32-x64/resources/app/ecl\_array.js-master/utils\_crc32.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ecl_array.js-master/utils_crc32.js) | JavaScript | 43 | 9 | 4 | 56 |
| [dist/TADjs Desktop-win32-x64/resources/app/electron/main.js](/dist/TADjs%20Desktop-win32-x64/resources/app/electron/main.js) | JavaScript | 419 | 55 | 77 | 551 |
| [dist/TADjs Desktop-win32-x64/resources/app/electron/plugin-manager.js](/dist/TADjs%20Desktop-win32-x64/resources/app/electron/plugin-manager.js) | JavaScript | 521 | 98 | 66 | 685 |
| [dist/TADjs Desktop-win32-x64/resources/app/electron/preload.js](/dist/TADjs%20Desktop-win32-x64/resources/app/electron/preload.js) | JavaScript | 10 | 6 | 3 | 19 |
| [dist/TADjs Desktop-win32-x64/resources/app/electron/test-main.js](/dist/TADjs%20Desktop-win32-x64/resources/app/electron/test-main.js) | JavaScript | 22 | 0 | 4 | 26 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/.eslintrc.json](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/.eslintrc.json) | JSON with Comments | 68 | 0 | 1 | 69 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/.travis.yml](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/.travis.yml) | YAML | 9 | 0 | 1 | 10 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/CHANGELOG.md](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/CHANGELOG.md) | Markdown | 33 | 0 | 32 | 65 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/README.md](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/README.md) | Markdown | 399 | 0 | 144 | 543 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/README\_ja.md](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/README_ja.md) | Markdown | 397 | 0 | 141 | 538 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/encoding.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/encoding.min.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/package.json](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/package.json) | JSON | 70 | 0 | 1 | 71 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/banner.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/banner.js) | JavaScript | 0 | 6 | 1 | 7 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/config.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/config.js) | JavaScript | 114 | 4 | 22 | 140 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/encoding-convert.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/encoding-convert.js) | JavaScript | 1,267 | 236 | 174 | 1,677 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/encoding-detect.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/encoding-detect.js) | JavaScript | 383 | 58 | 62 | 503 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/encoding-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/encoding-table.js) | JavaScript | 4 | 0 | 1 | 5 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/index.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/index.js) | JavaScript | 358 | 168 | 68 | 594 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/jis-to-utf8-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/jis-to-utf8-table.js) | JavaScript | 2 | 3 | 1 | 6 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/jisx0212-to-utf8-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/jisx0212-to-utf8-table.js) | JavaScript | 2 | 3 | 1 | 6 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/kana-case-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/kana-case-table.js) | JavaScript | 31 | 7 | 4 | 42 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/utf8-to-jis-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/utf8-to-jis-table.js) | JavaScript | 1,484 | 5 | 5 | 1,494 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/utf8-to-jisx0212-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/utf8-to-jisx0212-table.js) | JavaScript | 1,218 | 5 | 2 | 1,225 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/util.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/src/util.js) | JavaScript | 269 | 17 | 76 | 362 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/tests/.eslintrc.json](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/tests/.eslintrc.json) | JSON with Comments | 11 | 0 | 1 | 12 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-2.0.0/tests/test.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-2.0.0/tests/test.js) | JavaScript | 1,319 | 31 | 184 | 1,534 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/.eslintrc.json](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/.eslintrc.json) | JSON with Comments | 68 | 0 | 1 | 69 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/.travis.yml](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/.travis.yml) | YAML | 9 | 0 | 1 | 10 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/CHANGELOG.md](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/CHANGELOG.md) | Markdown | 33 | 0 | 32 | 65 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/README.md](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/README.md) | Markdown | 401 | 0 | 144 | 545 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/README\_ja.md](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/README_ja.md) | Markdown | 399 | 0 | 141 | 540 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/checkbox.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/checkbox.js) | JavaScript | 82 | 1 | 2 | 85 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/encoding.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/encoding.min.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/package.json](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/package.json) | JSON | 70 | 0 | 1 | 71 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/banner.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/banner.js) | JavaScript | 0 | 6 | 1 | 7 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/config.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/config.js) | JavaScript | 114 | 4 | 22 | 140 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/encoding-convert.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/encoding-convert.js) | JavaScript | 1,267 | 236 | 174 | 1,677 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/encoding-detect.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/encoding-detect.js) | JavaScript | 383 | 58 | 62 | 503 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/encoding-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/encoding-table.js) | JavaScript | 4 | 0 | 1 | 5 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/index.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/index.js) | JavaScript | 358 | 168 | 68 | 594 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/jis-to-utf8-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/jis-to-utf8-table.js) | JavaScript | 2 | 3 | 1 | 6 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/jisx0212-to-utf8-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/jisx0212-to-utf8-table.js) | JavaScript | 2 | 3 | 1 | 6 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/kana-case-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/kana-case-table.js) | JavaScript | 31 | 7 | 4 | 42 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/utf8-to-jis-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/utf8-to-jis-table.js) | JavaScript | 1,484 | 5 | 5 | 1,494 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/utf8-to-jisx0212-table.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/utf8-to-jisx0212-table.js) | JavaScript | 1,218 | 5 | 2 | 1,225 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/src/util.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/src/util.js) | JavaScript | 269 | 17 | 76 | 362 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/tests/.eslintrc.json](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/tests/.eslintrc.json) | JSON with Comments | 11 | 0 | 1 | 12 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.js-master/tests/test.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.js-master/tests/test.js) | JavaScript | 1,319 | 31 | 184 | 1,534 |
| [dist/TADjs Desktop-win32-x64/resources/app/encoding.min.js](/dist/TADjs%20Desktop-win32-x64/resources/app/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [dist/TADjs Desktop-win32-x64/resources/app/eslint.config.js](/dist/TADjs%20Desktop-win32-x64/resources/app/eslint.config.js) | JavaScript | 59 | 0 | 1 | 60 |
| [dist/TADjs Desktop-win32-x64/resources/app/f22289dc-a180-494c-a918-f856ea61b404.json](/dist/TADjs%20Desktop-win32-x64/resources/app/f22289dc-a180-494c-a918-f856ea61b404.json) | JSON | 42 | 0 | 1 | 43 |
| [dist/TADjs Desktop-win32-x64/resources/app/favicon.svg](/dist/TADjs%20Desktop-win32-x64/resources/app/favicon.svg) | XML | 8 | 3 | 2 | 13 |
| [dist/TADjs Desktop-win32-x64/resources/app/ftp-server.js](/dist/TADjs%20Desktop-win32-x64/resources/app/ftp-server.js) | JavaScript | 501 | 9 | 88 | 598 |
| [dist/TADjs Desktop-win32-x64/resources/app/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/index.html) | HTML | 1,079 | 3 | 196 | 1,278 |
| [dist/TADjs Desktop-win32-x64/resources/app/js/performance-utils.js](/dist/TADjs%20Desktop-win32-x64/resources/app/js/performance-utils.js) | JavaScript | 80 | 39 | 18 | 137 |
| [dist/TADjs Desktop-win32-x64/resources/app/js/real-object-system.js](/dist/TADjs%20Desktop-win32-x64/resources/app/js/real-object-system.js) | JavaScript | 329 | 103 | 93 | 525 |
| [dist/TADjs Desktop-win32-x64/resources/app/js/util.js](/dist/TADjs%20Desktop-win32-x64/resources/app/js/util.js) | JavaScript | 12 | 18 | 5 | 35 |
| [dist/TADjs Desktop-win32-x64/resources/app/js/uuid-v7.js](/dist/TADjs%20Desktop-win32-x64/resources/app/js/uuid-v7.js) | JavaScript | 31 | 37 | 14 | 82 |
| [dist/TADjs Desktop-win32-x64/resources/app/js/virtual-object-renderer.js](/dist/TADjs%20Desktop-win32-x64/resources/app/js/virtual-object-renderer.js) | JavaScript | 720 | 207 | 130 | 1,057 |
| [dist/TADjs Desktop-win32-x64/resources/app/lh5.js](/dist/TADjs%20Desktop-win32-x64/resources/app/lh5.js) | JavaScript | 297 | 60 | 75 | 432 |
| [dist/TADjs Desktop-win32-x64/resources/app/lib/encoding.min.js](/dist/TADjs%20Desktop-win32-x64/resources/app/lib/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [dist/TADjs Desktop-win32-x64/resources/app/package.json](/dist/TADjs%20Desktop-win32-x64/resources/app/package.json) | JSON | 84 | 0 | 1 | 85 |
| [dist/TADjs Desktop-win32-x64/resources/app/pages15.js](/dist/TADjs%20Desktop-win32-x64/resources/app/pages15.js) | JavaScript | 259 | 2 | 3 | 264 |
| [dist/TADjs Desktop-win32-x64/resources/app/pluginBuildGuide.md](/dist/TADjs%20Desktop-win32-x64/resources/app/pluginBuildGuide.md) | Markdown | 1,118 | 3 | 253 | 1,374 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/PLUGINS\_README.md](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/PLUGINS_README.md) | Markdown | 83 | 0 | 33 | 116 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/base-file-manager/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/base-file-manager/app.js) | JavaScript | 555 | 114 | 103 | 772 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/base-file-manager/d4797740-5936-4eb2-8ea6-f424870c2f14.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/base-file-manager/d4797740-5936-4eb2-8ea6-f424870c2f14.json) | JSON | 43 | 0 | 1 | 44 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/base-file-manager/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/base-file-manager/index.html) | HTML | 24 | 3 | 2 | 29 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/base-file-manager/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/base-file-manager/plugin.json) | JSON | 34 | 0 | 1 | 35 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/base-file-manager/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/base-file-manager/style.css) | PostCSS | 63 | 3 | 10 | 76 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-figure-editor/019a0f91-066f-706f-93da-ffe8150d6207.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-figure-editor/019a0f91-066f-706f-93da-ffe8150d6207.json) | JSON | 42 | 0 | 1 | 43 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-figure-editor/editor.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-figure-editor/editor.js) | JavaScript | 5,990 | 1,080 | 1,127 | 8,197 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-figure-editor/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-figure-editor/index.html) | HTML | 32 | 4 | 2 | 38 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-figure-editor/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-figure-editor/plugin.json) | JSON | 34 | 0 | 1 | 35 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-figure-editor/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-figure-editor/style.css) | PostCSS | 237 | 19 | 41 | 297 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-figure-editor/tool-panel.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-figure-editor/tool-panel.css) | PostCSS | 187 | 13 | 31 | 231 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-figure-editor/tool-panel.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-figure-editor/tool-panel.html) | HTML | 72 | 9 | 9 | 90 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-figure-editor/tool-panel.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-figure-editor/tool-panel.js) | JavaScript | 516 | 53 | 68 | 637 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-text-editor/019a1132-762b-7b02-ba2a-a918a9b37c39.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-text-editor/019a1132-762b-7b02-ba2a-a918a9b37c39.json) | JSON | 43 | 0 | 1 | 44 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-text-editor/editor.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-text-editor/editor.js) | JavaScript | 5,316 | 1,314 | 1,043 | 7,673 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-text-editor/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-text-editor/index.html) | HTML | 35 | 4 | 2 | 41 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-text-editor/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-text-editor/plugin.json) | JSON | 34 | 0 | 1 | 35 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/basic-text-editor/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/basic-text-editor/style.css) | PostCSS | 329 | 18 | 65 | 412 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/existing-data-exec/019a4a5c-7e2f-4b8a-9d3c-1f6e8a9b2c4d.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/existing-data-exec/019a4a5c-7e2f-4b8a-9d3c-1f6e8a9b2c4d.json) | JSON | 44 | 0 | 1 | 45 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/existing-data-exec/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/existing-data-exec/app.js) | JavaScript | 127 | 42 | 33 | 202 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/existing-data-exec/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/existing-data-exec/index.html) | HTML | 15 | 0 | 1 | 16 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/existing-data-exec/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/existing-data-exec/plugin.json) | JSON | 27 | 0 | 1 | 28 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/existing-data-exec/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/existing-data-exec/style.css) | PostCSS | 19 | 0 | 3 | 22 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/system-config/019a0035-8901-7bcd-9000-2222ccccdddd.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/system-config/019a0035-8901-7bcd-9000-2222ccccdddd.json) | JSON | 33 | 0 | 1 | 34 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/system-config/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/system-config/app.js) | JavaScript | 351 | 62 | 78 | 491 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/system-config/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/system-config/index.html) | HTML | 92 | 1 | 2 | 95 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/system-config/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/system-config/plugin.json) | JSON | 24 | 0 | 1 | 25 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/system-config/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/system-config/style.css) | PostCSS | 234 | 3 | 43 | 280 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/tadjs-view/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/tadjs-view/app.js) | JavaScript | 375 | 105 | 80 | 560 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/tadjs-view/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/tadjs-view/index.html) | HTML | 20 | 4 | 5 | 29 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/tadjs-view/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/tadjs-view/plugin.json) | JSON | 28 | 0 | 1 | 29 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/tadjs-view/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/tadjs-view/style.css) | PostCSS | 40 | 2 | 8 | 50 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/tadjs-view/tad.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/tadjs-view/tad.js) | JavaScript | 6,176 | 1,949 | 1,342 | 9,467 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/trash-real-objects/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/trash-real-objects/app.js) | JavaScript | 438 | 45 | 92 | 575 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/trash-real-objects/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/trash-real-objects/index.html) | HTML | 16 | 0 | 2 | 18 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/trash-real-objects/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/trash-real-objects/plugin.json) | JSON | 23 | 0 | 1 | 24 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/trash-real-objects/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/trash-real-objects/style.css) | PostCSS | 99 | 5 | 20 | 124 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/0199eb7d-6e78-79fb-fe14-1865d0a23d0f.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/0199eb7d-6e78-79fb-fe14-1865d0a23d0f.json) | JSON | 39 | 0 | 1 | 40 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/app.js) | JavaScript | 494 | 108 | 108 | 710 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/encoding.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/encoding.min.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/index.html) | HTML | 19 | 5 | 2 | 26 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/lh5.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/lh5.js) | JavaScript | 297 | 60 | 75 | 432 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/plugin.json) | JSON | 30 | 0 | 1 | 31 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/style.css) | PostCSS | 85 | 4 | 13 | 102 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/unpack-file/unpack.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/unpack-file/unpack.js) | JavaScript | 3,501 | 1,105 | 777 | 5,383 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/url-link-exec/019a4a5c-8888-4b8a-9d3c-1f6e8a9b2c4d.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/url-link-exec/019a4a5c-8888-4b8a-9d3c-1f6e8a9b2c4d.json) | JSON | 44 | 0 | 1 | 45 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/url-link-exec/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/url-link-exec/app.js) | JavaScript | 136 | 25 | 37 | 198 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/url-link-exec/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/url-link-exec/index.html) | HTML | 15 | 0 | 1 | 16 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/url-link-exec/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/url-link-exec/plugin.json) | JSON | 27 | 0 | 1 | 28 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/url-link-exec/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/url-link-exec/style.css) | PostCSS | 18 | 0 | 3 | 21 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/user-config/019a0035-7890-7abc-8000-1111aaaabbbb.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/user-config/019a0035-7890-7abc-8000-1111aaaabbbb.json) | JSON | 33 | 0 | 1 | 34 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/user-config/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/user-config/app.js) | JavaScript | 340 | 56 | 65 | 461 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/user-config/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/user-config/index.html) | HTML | 143 | 2 | 2 | 147 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/user-config/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/user-config/plugin.json) | JSON | 23 | 0 | 1 | 24 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/user-config/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/user-config/style.css) | PostCSS | 180 | 1 | 31 | 212 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/virtual-object-list/0199ce60-532a-7670-b8bc-84c970de11dc.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/virtual-object-list/0199ce60-532a-7670-b8bc-84c970de11dc.json) | JSON | 43 | 0 | 1 | 44 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/virtual-object-list/app.js](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/virtual-object-list/app.js) | JavaScript | 4,354 | 1,033 | 865 | 6,252 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/virtual-object-list/index.html](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/virtual-object-list/index.html) | HTML | 32 | 3 | 2 | 37 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/virtual-object-list/plugin.json](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/virtual-object-list/plugin.json) | JSON | 34 | 0 | 1 | 35 |
| [dist/TADjs Desktop-win32-x64/resources/app/plugins/virtual-object-list/style.css](/dist/TADjs%20Desktop-win32-x64/resources/app/plugins/virtual-object-list/style.css) | PostCSS | 128 | 8 | 27 | 163 |
| [dist/TADjs Desktop-win32-x64/resources/app/scripts/patch-font-list.js](/dist/TADjs%20Desktop-win32-x64/resources/app/scripts/patch-font-list.js) | JavaScript | 25 | 10 | 12 | 47 |
| [dist/TADjs Desktop-win32-x64/resources/app/tad.js](/dist/TADjs%20Desktop-win32-x64/resources/app/tad.js) | JavaScript | 6,104 | 1,946 | 1,335 | 9,385 |
| [dist/TADjs Desktop-win32-x64/resources/app/tadjs-desktop.css](/dist/TADjs%20Desktop-win32-x64/resources/app/tadjs-desktop.css) | PostCSS | 1,105 | 78 | 197 | 1,380 |
| [dist/TADjs Desktop-win32-x64/resources/app/tadjs-desktop.html](/dist/TADjs%20Desktop-win32-x64/resources/app/tadjs-desktop.html) | HTML | 71 | 10 | 10 | 91 |
| [dist/TADjs Desktop-win32-x64/resources/app/tadjs-desktop.js](/dist/TADjs%20Desktop-win32-x64/resources/app/tadjs-desktop.js) | JavaScript | 5,776 | 1,416 | 1,052 | 8,244 |
| [dist/TADjs Desktop-win32-x64/resources/app/tadjs\_desktop\_README.md](/dist/TADjs%20Desktop-win32-x64/resources/app/tadjs_desktop_README.md) | Markdown | 262 | 0 | 122 | 384 |
| [dist/TADjs Desktop-win32-x64/resources/app/test-font-list.js](/dist/TADjs%20Desktop-win32-x64/resources/app/test-font-list.js) | JavaScript | 59 | 5 | 8 | 72 |
| [dist/TADjs Desktop-win32-x64/resources/app/test-uuid.js](/dist/TADjs%20Desktop-win32-x64/resources/app/test-uuid.js) | JavaScript | 62 | 28 | 23 | 113 |
| [dist/TADjs Desktop-win32-x64/resources/app/test-virtual-object-renderer.html](/dist/TADjs%20Desktop-win32-x64/resources/app/test-virtual-object-renderer.html) | HTML | 454 | 0 | 72 | 526 |
| [dist/TADjs Desktop-win32-x64/resources/app/test-virtual-object-renderer.js](/dist/TADjs%20Desktop-win32-x64/resources/app/test-virtual-object-renderer.js) | JavaScript | 183 | 26 | 35 | 244 |
| [dist/TADjs Desktop-win32-x64/resources/app/xtaddata/0199ce83-6e83-7d42-8962-d2ad8c721654.json](/dist/TADjs%20Desktop-win32-x64/resources/app/xtaddata/0199ce83-6e83-7d42-8962-d2ad8c721654.json) | JSON | 49 | 0 | 0 | 49 |
| [dist/TADjs Desktop-win32-x64/resources/app/xtaddata/019a4370-3819-79a2-9758-881e1e0de90a.json](/dist/TADjs%20Desktop-win32-x64/resources/app/xtaddata/019a4370-3819-79a2-9758-881e1e0de90a.json) | JSON | 43 | 0 | 1 | 44 |
| [dist/TADjs Desktop-win32-x64/resources/app/xtaddata/019a6c96-e262-7dfd-a3bc-1e85d495d60d.json](/dist/TADjs%20Desktop-win32-x64/resources/app/xtaddata/019a6c96-e262-7dfd-a3bc-1e85d495d60d.json) | JSON | 43 | 0 | 0 | 43 |
| [dist/TADjs Desktop-win32-x64/resources/app/xtaddata/019a6c9a-fbc2-76c1-b965-4ac1f7e4dcb7.json](/dist/TADjs%20Desktop-win32-x64/resources/app/xtaddata/019a6c9a-fbc2-76c1-b965-4ac1f7e4dcb7.json) | JSON | 43 | 0 | 0 | 43 |
| [dist/TADjs Desktop-win32-x64/resources/app/xtaddata/019a6c9b-e67e-7a35-a461-0d199550e4cf.json](/dist/TADjs%20Desktop-win32-x64/resources/app/xtaddata/019a6c9b-e67e-7a35-a461-0d199550e4cf.json) | JSON | 43 | 0 | 0 | 43 |
| [dist/TADjs Desktop-win32-x64/resources/app/xtaddata/f22289dc-a180-494c-a918-f856ea61b404.json](/dist/TADjs%20Desktop-win32-x64/resources/app/xtaddata/f22289dc-a180-494c-a918-f856ea61b404.json) | JSON | 42 | 0 | 0 | 42 |
| [dist/TADjs Desktop-win32-x64/tad.js](/dist/TADjs%20Desktop-win32-x64/tad.js) | JavaScript | 6,104 | 1,946 | 1,335 | 9,385 |
| [dist/TADjs Desktop-win32-x64/vk\_swiftshader\_icd.json](/dist/TADjs%20Desktop-win32-x64/vk_swiftshader_icd.json) | JSON | 1 | 0 | 0 | 1 |
| [ecl\_array.js-master/README.md](/ecl_array.js-master/README.md) | Markdown | 23 | 0 | 12 | 35 |
| [ecl\_array.js-master/ecl.js](/ecl_array.js-master/ecl.js) | JavaScript | 185 | 5 | 21 | 211 |
| [ecl\_array.js-master/ecl\_2004.js](/ecl_array.js-master/ecl_2004.js) | JavaScript | 192 | 92 | 6 | 290 |
| [ecl\_array.js-master/ecl\_2004.min.js](/ecl_array.js-master/ecl_2004.min.js) | JavaScript | 12 | 0 | 1 | 13 |
| [ecl\_array.js-master/ecl\_array.js](/ecl_array.js-master/ecl_array.js) | JavaScript | 592 | 423 | 7 | 1,022 |
| [ecl\_array.js-master/ecl\_array.min.js](/ecl_array.js-master/ecl_array.min.js) | JavaScript | 30 | 0 | 1 | 31 |
| [ecl\_array.js-master/encoding.js](/ecl_array.js-master/encoding.js) | JavaScript | 3,925 | 434 | 61 | 4,420 |
| [ecl\_array.js-master/encodingtest.html](/ecl_array.js-master/encodingtest.html) | HTML | 532 | 22 | 40 | 594 |
| [ecl\_array.js-master/inflate.min.js](/ecl_array.js-master/inflate.min.js) | JavaScript | 16 | 0 | 1 | 17 |
| [ecl\_array.js-master/text-encoding/LICENSE.md](/ecl_array.js-master/text-encoding/LICENSE.md) | Markdown | 169 | 0 | 34 | 203 |
| [ecl\_array.js-master/text-encoding/lib/encoding-indexes.js](/ecl_array.js-master/text-encoding/lib/encoding-indexes.js) | JavaScript | 38 | 14 | 3 | 55 |
| [ecl\_array.js-master/text-encoding/lib/encoding.js](/ecl_array.js-master/text-encoding/lib/encoding.js) | JavaScript | 1,846 | 451 | 138 | 2,435 |
| [ecl\_array.js-master/utils.js](/ecl_array.js-master/utils.js) | JavaScript | 299 | 35 | 12 | 346 |
| [ecl\_array.js-master/utils\_crc32.js](/ecl_array.js-master/utils_crc32.js) | JavaScript | 43 | 9 | 4 | 56 |
| [electron/main.js](/electron/main.js) | JavaScript | 419 | 55 | 77 | 551 |
| [electron/plugin-manager.js](/electron/plugin-manager.js) | JavaScript | 521 | 98 | 66 | 685 |
| [electron/preload.js](/electron/preload.js) | JavaScript | 10 | 6 | 3 | 19 |
| [electron/test-main.js](/electron/test-main.js) | JavaScript | 22 | 0 | 4 | 26 |
| [encoding.js](/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [encoding.js-2.0.0/.eslintrc.json](/encoding.js-2.0.0/.eslintrc.json) | JSON with Comments | 68 | 0 | 1 | 69 |
| [encoding.js-2.0.0/.travis.yml](/encoding.js-2.0.0/.travis.yml) | YAML | 9 | 0 | 1 | 10 |
| [encoding.js-2.0.0/CHANGELOG.md](/encoding.js-2.0.0/CHANGELOG.md) | Markdown | 33 | 0 | 32 | 65 |
| [encoding.js-2.0.0/README.md](/encoding.js-2.0.0/README.md) | Markdown | 399 | 0 | 144 | 543 |
| [encoding.js-2.0.0/README\_ja.md](/encoding.js-2.0.0/README_ja.md) | Markdown | 397 | 0 | 141 | 538 |
| [encoding.js-2.0.0/encoding.js](/encoding.js-2.0.0/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [encoding.js-2.0.0/encoding.min.js](/encoding.js-2.0.0/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [encoding.js-2.0.0/package-lock.json](/encoding.js-2.0.0/package-lock.json) | JSON | 3,645 | 0 | 1 | 3,646 |
| [encoding.js-2.0.0/package.json](/encoding.js-2.0.0/package.json) | JSON | 70 | 0 | 1 | 71 |
| [encoding.js-2.0.0/src/banner.js](/encoding.js-2.0.0/src/banner.js) | JavaScript | 0 | 6 | 1 | 7 |
| [encoding.js-2.0.0/src/config.js](/encoding.js-2.0.0/src/config.js) | JavaScript | 114 | 4 | 22 | 140 |
| [encoding.js-2.0.0/src/encoding-convert.js](/encoding.js-2.0.0/src/encoding-convert.js) | JavaScript | 1,267 | 236 | 174 | 1,677 |
| [encoding.js-2.0.0/src/encoding-detect.js](/encoding.js-2.0.0/src/encoding-detect.js) | JavaScript | 383 | 58 | 62 | 503 |
| [encoding.js-2.0.0/src/encoding-table.js](/encoding.js-2.0.0/src/encoding-table.js) | JavaScript | 4 | 0 | 1 | 5 |
| [encoding.js-2.0.0/src/index.js](/encoding.js-2.0.0/src/index.js) | JavaScript | 358 | 168 | 68 | 594 |
| [encoding.js-2.0.0/src/jis-to-utf8-table.js](/encoding.js-2.0.0/src/jis-to-utf8-table.js) | JavaScript | 2 | 3 | 1 | 6 |
| [encoding.js-2.0.0/src/jisx0212-to-utf8-table.js](/encoding.js-2.0.0/src/jisx0212-to-utf8-table.js) | JavaScript | 2 | 3 | 1 | 6 |
| [encoding.js-2.0.0/src/kana-case-table.js](/encoding.js-2.0.0/src/kana-case-table.js) | JavaScript | 31 | 7 | 4 | 42 |
| [encoding.js-2.0.0/src/utf8-to-jis-table.js](/encoding.js-2.0.0/src/utf8-to-jis-table.js) | JavaScript | 1,484 | 5 | 5 | 1,494 |
| [encoding.js-2.0.0/src/utf8-to-jisx0212-table.js](/encoding.js-2.0.0/src/utf8-to-jisx0212-table.js) | JavaScript | 1,218 | 5 | 2 | 1,225 |
| [encoding.js-2.0.0/src/util.js](/encoding.js-2.0.0/src/util.js) | JavaScript | 269 | 17 | 76 | 362 |
| [encoding.js-2.0.0/tests/.eslintrc.json](/encoding.js-2.0.0/tests/.eslintrc.json) | JSON with Comments | 11 | 0 | 1 | 12 |
| [encoding.js-2.0.0/tests/test.js](/encoding.js-2.0.0/tests/test.js) | JavaScript | 1,319 | 31 | 184 | 1,534 |
| [encoding.js-master/.eslintrc.json](/encoding.js-master/.eslintrc.json) | JSON with Comments | 68 | 0 | 1 | 69 |
| [encoding.js-master/.travis.yml](/encoding.js-master/.travis.yml) | YAML | 9 | 0 | 1 | 10 |
| [encoding.js-master/CHANGELOG.md](/encoding.js-master/CHANGELOG.md) | Markdown | 33 | 0 | 32 | 65 |
| [encoding.js-master/README.md](/encoding.js-master/README.md) | Markdown | 401 | 0 | 144 | 545 |
| [encoding.js-master/README\_ja.md](/encoding.js-master/README_ja.md) | Markdown | 399 | 0 | 141 | 540 |
| [encoding.js-master/checkbox.js](/encoding.js-master/checkbox.js) | JavaScript | 82 | 1 | 2 | 85 |
| [encoding.js-master/encoding.js](/encoding.js-master/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [encoding.js-master/encoding.min.js](/encoding.js-master/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [encoding.js-master/package-lock.json](/encoding.js-master/package-lock.json) | JSON | 3,645 | 0 | 1 | 3,646 |
| [encoding.js-master/package.json](/encoding.js-master/package.json) | JSON | 70 | 0 | 1 | 71 |
| [encoding.js-master/src/banner.js](/encoding.js-master/src/banner.js) | JavaScript | 0 | 6 | 1 | 7 |
| [encoding.js-master/src/config.js](/encoding.js-master/src/config.js) | JavaScript | 114 | 4 | 22 | 140 |
| [encoding.js-master/src/encoding-convert.js](/encoding.js-master/src/encoding-convert.js) | JavaScript | 1,267 | 236 | 174 | 1,677 |
| [encoding.js-master/src/encoding-detect.js](/encoding.js-master/src/encoding-detect.js) | JavaScript | 383 | 58 | 62 | 503 |
| [encoding.js-master/src/encoding-table.js](/encoding.js-master/src/encoding-table.js) | JavaScript | 4 | 0 | 1 | 5 |
| [encoding.js-master/src/index.js](/encoding.js-master/src/index.js) | JavaScript | 358 | 168 | 68 | 594 |
| [encoding.js-master/src/jis-to-utf8-table.js](/encoding.js-master/src/jis-to-utf8-table.js) | JavaScript | 2 | 3 | 1 | 6 |
| [encoding.js-master/src/jisx0212-to-utf8-table.js](/encoding.js-master/src/jisx0212-to-utf8-table.js) | JavaScript | 2 | 3 | 1 | 6 |
| [encoding.js-master/src/kana-case-table.js](/encoding.js-master/src/kana-case-table.js) | JavaScript | 31 | 7 | 4 | 42 |
| [encoding.js-master/src/utf8-to-jis-table.js](/encoding.js-master/src/utf8-to-jis-table.js) | JavaScript | 1,484 | 5 | 5 | 1,494 |
| [encoding.js-master/src/utf8-to-jisx0212-table.js](/encoding.js-master/src/utf8-to-jisx0212-table.js) | JavaScript | 1,218 | 5 | 2 | 1,225 |
| [encoding.js-master/src/util.js](/encoding.js-master/src/util.js) | JavaScript | 269 | 17 | 76 | 362 |
| [encoding.js-master/tests/.eslintrc.json](/encoding.js-master/tests/.eslintrc.json) | JSON with Comments | 11 | 0 | 1 | 12 |
| [encoding.js-master/tests/test.js](/encoding.js-master/tests/test.js) | JavaScript | 1,319 | 31 | 184 | 1,534 |
| [encoding.min.js](/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [eslint.config.js](/eslint.config.js) | JavaScript | 59 | 0 | 1 | 60 |
| [f22289dc-a180-494c-a918-f856ea61b404.json](/f22289dc-a180-494c-a918-f856ea61b404.json) | JSON | 42 | 0 | 1 | 43 |
| [favicon.svg](/favicon.svg) | XML | 8 | 3 | 2 | 13 |
| [ftp-server.js](/ftp-server.js) | JavaScript | 501 | 9 | 88 | 598 |
| [index.html](/index.html) | HTML | 1,079 | 3 | 196 | 1,278 |
| [js/performance-utils.js](/js/performance-utils.js) | JavaScript | 80 | 39 | 18 | 137 |
| [js/real-object-system.js](/js/real-object-system.js) | JavaScript | 329 | 103 | 93 | 525 |
| [js/util.js](/js/util.js) | JavaScript | 12 | 18 | 5 | 35 |
| [js/uuid-v7.js](/js/uuid-v7.js) | JavaScript | 31 | 37 | 14 | 82 |
| [js/virtual-object-renderer.js](/js/virtual-object-renderer.js) | JavaScript | 720 | 207 | 130 | 1,057 |
| [lh5.js](/lh5.js) | JavaScript | 297 | 60 | 75 | 432 |
| [lib/encoding.min.js](/lib/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [package-lock.json](/package-lock.json) | JSON | 4,880 | 0 | 1 | 4,881 |
| [package.json](/package.json) | JSON | 84 | 0 | 1 | 85 |
| [pages15.js](/pages15.js) | JavaScript | 259 | 2 | 3 | 264 |
| [pluginBuildGuide.md](/pluginBuildGuide.md) | Markdown | 1,118 | 3 | 253 | 1,374 |
| [plugins/PLUGINS\_README.md](/plugins/PLUGINS_README.md) | Markdown | 83 | 0 | 33 | 116 |
| [plugins/base-file-manager/app.js](/plugins/base-file-manager/app.js) | JavaScript | 555 | 114 | 103 | 772 |
| [plugins/base-file-manager/d4797740-5936-4eb2-8ea6-f424870c2f14.json](/plugins/base-file-manager/d4797740-5936-4eb2-8ea6-f424870c2f14.json) | JSON | 43 | 0 | 1 | 44 |
| [plugins/base-file-manager/index.html](/plugins/base-file-manager/index.html) | HTML | 24 | 3 | 2 | 29 |
| [plugins/base-file-manager/plugin.json](/plugins/base-file-manager/plugin.json) | JSON | 34 | 0 | 1 | 35 |
| [plugins/base-file-manager/style.css](/plugins/base-file-manager/style.css) | PostCSS | 63 | 3 | 10 | 76 |
| [plugins/basic-figure-editor/019a0f91-066f-706f-93da-ffe8150d6207.json](/plugins/basic-figure-editor/019a0f91-066f-706f-93da-ffe8150d6207.json) | JSON | 42 | 0 | 1 | 43 |
| [plugins/basic-figure-editor/editor.js](/plugins/basic-figure-editor/editor.js) | JavaScript | 5,990 | 1,080 | 1,127 | 8,197 |
| [plugins/basic-figure-editor/index.html](/plugins/basic-figure-editor/index.html) | HTML | 32 | 4 | 2 | 38 |
| [plugins/basic-figure-editor/plugin.json](/plugins/basic-figure-editor/plugin.json) | JSON | 34 | 0 | 1 | 35 |
| [plugins/basic-figure-editor/style.css](/plugins/basic-figure-editor/style.css) | PostCSS | 237 | 19 | 41 | 297 |
| [plugins/basic-figure-editor/tool-panel.css](/plugins/basic-figure-editor/tool-panel.css) | PostCSS | 187 | 13 | 31 | 231 |
| [plugins/basic-figure-editor/tool-panel.html](/plugins/basic-figure-editor/tool-panel.html) | HTML | 72 | 9 | 9 | 90 |
| [plugins/basic-figure-editor/tool-panel.js](/plugins/basic-figure-editor/tool-panel.js) | JavaScript | 516 | 53 | 68 | 637 |
| [plugins/basic-text-editor/019a1132-762b-7b02-ba2a-a918a9b37c39.json](/plugins/basic-text-editor/019a1132-762b-7b02-ba2a-a918a9b37c39.json) | JSON | 43 | 0 | 1 | 44 |
| [plugins/basic-text-editor/editor.js](/plugins/basic-text-editor/editor.js) | JavaScript | 5,316 | 1,314 | 1,043 | 7,673 |
| [plugins/basic-text-editor/index.html](/plugins/basic-text-editor/index.html) | HTML | 35 | 4 | 2 | 41 |
| [plugins/basic-text-editor/plugin.json](/plugins/basic-text-editor/plugin.json) | JSON | 34 | 0 | 1 | 35 |
| [plugins/basic-text-editor/style.css](/plugins/basic-text-editor/style.css) | PostCSS | 329 | 18 | 65 | 412 |
| [plugins/existing-data-exec/019a4a5c-7e2f-4b8a-9d3c-1f6e8a9b2c4d.json](/plugins/existing-data-exec/019a4a5c-7e2f-4b8a-9d3c-1f6e8a9b2c4d.json) | JSON | 44 | 0 | 1 | 45 |
| [plugins/existing-data-exec/app.js](/plugins/existing-data-exec/app.js) | JavaScript | 127 | 42 | 33 | 202 |
| [plugins/existing-data-exec/index.html](/plugins/existing-data-exec/index.html) | HTML | 15 | 0 | 1 | 16 |
| [plugins/existing-data-exec/plugin.json](/plugins/existing-data-exec/plugin.json) | JSON | 27 | 0 | 1 | 28 |
| [plugins/existing-data-exec/style.css](/plugins/existing-data-exec/style.css) | PostCSS | 19 | 0 | 3 | 22 |
| [plugins/system-config/019a0035-8901-7bcd-9000-2222ccccdddd.json](/plugins/system-config/019a0035-8901-7bcd-9000-2222ccccdddd.json) | JSON | 33 | 0 | 1 | 34 |
| [plugins/system-config/app.js](/plugins/system-config/app.js) | JavaScript | 351 | 62 | 78 | 491 |
| [plugins/system-config/index.html](/plugins/system-config/index.html) | HTML | 92 | 1 | 2 | 95 |
| [plugins/system-config/plugin.json](/plugins/system-config/plugin.json) | JSON | 24 | 0 | 1 | 25 |
| [plugins/system-config/style.css](/plugins/system-config/style.css) | PostCSS | 234 | 3 | 43 | 280 |
| [plugins/tadjs-view/app.js](/plugins/tadjs-view/app.js) | JavaScript | 375 | 105 | 80 | 560 |
| [plugins/tadjs-view/index.html](/plugins/tadjs-view/index.html) | HTML | 20 | 4 | 5 | 29 |
| [plugins/tadjs-view/plugin.json](/plugins/tadjs-view/plugin.json) | JSON | 28 | 0 | 1 | 29 |
| [plugins/tadjs-view/style.css](/plugins/tadjs-view/style.css) | PostCSS | 40 | 2 | 8 | 50 |
| [plugins/tadjs-view/tad.js](/plugins/tadjs-view/tad.js) | JavaScript | 6,176 | 1,949 | 1,342 | 9,467 |
| [plugins/trash-real-objects/app.js](/plugins/trash-real-objects/app.js) | JavaScript | 438 | 45 | 92 | 575 |
| [plugins/trash-real-objects/index.html](/plugins/trash-real-objects/index.html) | HTML | 16 | 0 | 2 | 18 |
| [plugins/trash-real-objects/plugin.json](/plugins/trash-real-objects/plugin.json) | JSON | 23 | 0 | 1 | 24 |
| [plugins/trash-real-objects/style.css](/plugins/trash-real-objects/style.css) | PostCSS | 99 | 5 | 20 | 124 |
| [plugins/unpack-file/0199eb7d-6e78-79fb-fe14-1865d0a23d0f.json](/plugins/unpack-file/0199eb7d-6e78-79fb-fe14-1865d0a23d0f.json) | JSON | 39 | 0 | 1 | 40 |
| [plugins/unpack-file/app.js](/plugins/unpack-file/app.js) | JavaScript | 494 | 108 | 108 | 710 |
| [plugins/unpack-file/encoding.js](/plugins/unpack-file/encoding.js) | JavaScript | 5,149 | 512 | 417 | 6,078 |
| [plugins/unpack-file/encoding.min.js](/plugins/unpack-file/encoding.min.js) | JavaScript | 1 | 7 | 0 | 8 |
| [plugins/unpack-file/index.html](/plugins/unpack-file/index.html) | HTML | 19 | 5 | 2 | 26 |
| [plugins/unpack-file/lh5.js](/plugins/unpack-file/lh5.js) | JavaScript | 297 | 60 | 75 | 432 |
| [plugins/unpack-file/plugin.json](/plugins/unpack-file/plugin.json) | JSON | 30 | 0 | 1 | 31 |
| [plugins/unpack-file/style.css](/plugins/unpack-file/style.css) | PostCSS | 85 | 4 | 13 | 102 |
| [plugins/unpack-file/unpack.js](/plugins/unpack-file/unpack.js) | JavaScript | 3,501 | 1,105 | 777 | 5,383 |
| [plugins/url-link-exec/019a4a5c-8888-4b8a-9d3c-1f6e8a9b2c4d.json](/plugins/url-link-exec/019a4a5c-8888-4b8a-9d3c-1f6e8a9b2c4d.json) | JSON | 44 | 0 | 1 | 45 |
| [plugins/url-link-exec/app.js](/plugins/url-link-exec/app.js) | JavaScript | 136 | 25 | 37 | 198 |
| [plugins/url-link-exec/index.html](/plugins/url-link-exec/index.html) | HTML | 15 | 0 | 1 | 16 |
| [plugins/url-link-exec/plugin.json](/plugins/url-link-exec/plugin.json) | JSON | 27 | 0 | 1 | 28 |
| [plugins/url-link-exec/style.css](/plugins/url-link-exec/style.css) | PostCSS | 18 | 0 | 3 | 21 |
| [plugins/user-config/019a0035-7890-7abc-8000-1111aaaabbbb.json](/plugins/user-config/019a0035-7890-7abc-8000-1111aaaabbbb.json) | JSON | 33 | 0 | 1 | 34 |
| [plugins/user-config/app.js](/plugins/user-config/app.js) | JavaScript | 340 | 56 | 65 | 461 |
| [plugins/user-config/index.html](/plugins/user-config/index.html) | HTML | 143 | 2 | 2 | 147 |
| [plugins/user-config/plugin.json](/plugins/user-config/plugin.json) | JSON | 23 | 0 | 1 | 24 |
| [plugins/user-config/style.css](/plugins/user-config/style.css) | PostCSS | 180 | 1 | 31 | 212 |
| [plugins/virtual-object-list/0199ce60-532a-7670-b8bc-84c970de11dc.json](/plugins/virtual-object-list/0199ce60-532a-7670-b8bc-84c970de11dc.json) | JSON | 43 | 0 | 1 | 44 |
| [plugins/virtual-object-list/app.js](/plugins/virtual-object-list/app.js) | JavaScript | 4,354 | 1,033 | 865 | 6,252 |
| [plugins/virtual-object-list/index.html](/plugins/virtual-object-list/index.html) | HTML | 32 | 3 | 2 | 37 |
| [plugins/virtual-object-list/plugin.json](/plugins/virtual-object-list/plugin.json) | JSON | 34 | 0 | 1 | 35 |
| [plugins/virtual-object-list/style.css](/plugins/virtual-object-list/style.css) | PostCSS | 128 | 8 | 27 | 163 |
| [rename-and-build.ps1](/rename-and-build.ps1) | PowerShell | 16 | 2 | 3 | 21 |
| [scripts/patch-font-list.js](/scripts/patch-font-list.js) | JavaScript | 25 | 10 | 12 | 47 |
| [tad.js](/tad.js) | JavaScript | 6,104 | 1,946 | 1,335 | 9,385 |
| [tadjs-desktop.css](/tadjs-desktop.css) | PostCSS | 1,105 | 78 | 197 | 1,380 |
| [tadjs-desktop.html](/tadjs-desktop.html) | HTML | 71 | 10 | 10 | 91 |
| [tadjs-desktop.js](/tadjs-desktop.js) | JavaScript | 5,776 | 1,416 | 1,052 | 8,244 |
| [tadjs\_desktop\_README.md](/tadjs_desktop_README.md) | Markdown | 262 | 0 | 122 | 384 |
| [test-font-list.js](/test-font-list.js) | JavaScript | 59 | 5 | 8 | 72 |
| [test-uuid.js](/test-uuid.js) | JavaScript | 62 | 28 | 23 | 113 |
| [test-virtual-object-renderer.html](/test-virtual-object-renderer.html) | HTML | 454 | 0 | 72 | 526 |
| [test-virtual-object-renderer.js](/test-virtual-object-renderer.js) | JavaScript | 183 | 26 | 35 | 244 |
| [xtaddata/0199ce83-6e83-7d42-8962-d2ad8c721654.json](/xtaddata/0199ce83-6e83-7d42-8962-d2ad8c721654.json) | JSON | 49 | 0 | 0 | 49 |
| [xtaddata/019a4370-3819-79a2-9758-881e1e0de90a.json](/xtaddata/019a4370-3819-79a2-9758-881e1e0de90a.json) | JSON | 43 | 0 | 1 | 44 |
| [xtaddata/019a6c96-e262-7dfd-a3bc-1e85d495d60d.json](/xtaddata/019a6c96-e262-7dfd-a3bc-1e85d495d60d.json) | JSON | 43 | 0 | 0 | 43 |
| [xtaddata/019a6c9a-fbc2-76c1-b965-4ac1f7e4dcb7.json](/xtaddata/019a6c9a-fbc2-76c1-b965-4ac1f7e4dcb7.json) | JSON | 43 | 0 | 0 | 43 |
| [xtaddata/019a6c9b-e67e-7a35-a461-0d199550e4cf.json](/xtaddata/019a6c9b-e67e-7a35-a461-0d199550e4cf.json) | JSON | 43 | 0 | 0 | 43 |
| [xtaddata/f22289dc-a180-494c-a918-f856ea61b404.json](/xtaddata/f22289dc-a180-494c-a918-f856ea61b404.json) | JSON | 42 | 0 | 0 | 42 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)