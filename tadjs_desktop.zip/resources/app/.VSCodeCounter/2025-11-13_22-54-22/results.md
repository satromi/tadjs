# Summary

Date : 2025-11-13 22:54:22

Directory c:\\btron-desktop

Total : 350 files,  338441 codes, 34663 comments, 57687 blanks, all 430791 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JavaScript | 167 | 181,720 | 34,193 | 25,900 | 241,813 |
| HTML | 33 | 125,721 | 140 | 27,408 | 153,269 |
| JSON | 71 | 14,891 | 0 | 55 | 14,946 |
| Markdown | 32 | 10,152 | 6 | 3,304 | 13,462 |
| PostCSS | 26 | 5,448 | 308 | 984 | 6,740 |
| JSON with Comments | 10 | 372 | 0 | 8 | 380 |
| PowerShell | 5 | 85 | 10 | 20 | 115 |
| YAML | 4 | 36 | 0 | 4 | 40 |
| XML | 2 | 16 | 6 | 4 | 26 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 350 | 338,441 | 34,663 | 57,687 | 430,791 |
| . (Files) | 33 | 29,460 | 4,133 | 4,488 | 38,081 |
| .claude | 1 | 35 | 0 | 1 | 36 |
| dist | 176 | 229,044 | 18,559 | 43,062 | 290,665 |
| dist\\TADjs Desktop-win32-x64 | 176 | 229,044 | 18,559 | 43,062 | 290,665 |
| dist\\TADjs Desktop-win32-x64 (Files) | 11 | 131,937 | 2,465 | 28,461 | 162,863 |
| dist\\TADjs Desktop-win32-x64\\resources | 165 | 97,107 | 16,094 | 14,601 | 127,802 |
| dist\\TADjs Desktop-win32-x64\\resources\\app | 165 | 97,107 | 16,094 | 14,601 | 127,802 |
| dist\\TADjs Desktop-win32-x64\\resources\\app (Files) | 27 | 24,495 | 4,123 | 4,467 | 33,085 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\ecl_array.js-master | 14 | 7,902 | 1,485 | 341 | 9,728 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\ecl_array.js-master (Files) | 11 | 5,849 | 1,020 | 166 | 7,035 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\ecl_array.js-master\\text-encoding | 3 | 2,053 | 465 | 175 | 2,693 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\ecl_array.js-master\\text-encoding (Files) | 1 | 169 | 0 | 34 | 203 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\ecl_array.js-master\\text-encoding\\lib | 2 | 1,884 | 465 | 141 | 2,490 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\electron | 4 | 972 | 159 | 150 | 1,281 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\encoding.js-2.0.0 | 22 | 12,588 | 1,062 | 1,339 | 14,989 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\encoding.js-2.0.0 (Files) | 8 | 6,126 | 519 | 737 | 7,382 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\encoding.js-2.0.0\\src | 12 | 5,132 | 512 | 417 | 6,061 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\encoding.js-2.0.0\\tests | 2 | 1,330 | 31 | 185 | 1,546 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\encoding.js-master | 23 | 12,674 | 1,063 | 1,341 | 15,078 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\encoding.js-master (Files) | 9 | 6,212 | 520 | 739 | 7,471 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\encoding.js-master\\src | 12 | 5,132 | 512 | 417 | 6,061 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\encoding.js-master\\tests | 2 | 1,330 | 31 | 185 | 1,546 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\js | 5 | 1,172 | 404 | 260 | 1,836 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\lib | 1 | 1 | 7 | 0 | 8 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins | 62 | 37,015 | 7,781 | 6,690 | 51,486 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins (Files) | 1 | 83 | 0 | 33 | 116 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\base-file-manager | 5 | 719 | 120 | 117 | 956 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\basic-figure-editor | 8 | 7,110 | 1,178 | 1,280 | 9,568 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\basic-text-editor | 5 | 5,757 | 1,336 | 1,112 | 8,205 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\existing-data-exec | 5 | 232 | 42 | 39 | 313 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\system-config | 5 | 734 | 66 | 125 | 925 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\tadjs-view | 5 | 6,639 | 2,060 | 1,436 | 10,135 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\trash-real-objects | 4 | 576 | 50 | 115 | 741 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\unpack-file | 9 | 9,615 | 1,801 | 1,394 | 12,810 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\url-link-exec | 5 | 240 | 25 | 43 | 308 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\user-config | 5 | 719 | 59 | 100 | 878 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\plugins\\virtual-object-list | 5 | 4,591 | 1,044 | 896 | 6,531 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\scripts | 1 | 25 | 10 | 12 | 47 |
| dist\\TADjs Desktop-win32-x64\\resources\\app\\xtaddata | 6 | 263 | 0 | 1 | 264 |
| ecl_array.js-master | 14 | 7,902 | 1,485 | 341 | 9,728 |
| ecl_array.js-master (Files) | 11 | 5,849 | 1,020 | 166 | 7,035 |
| ecl_array.js-master\\text-encoding | 3 | 2,053 | 465 | 175 | 2,693 |
| ecl_array.js-master\\text-encoding (Files) | 1 | 169 | 0 | 34 | 203 |
| ecl_array.js-master\\text-encoding\\lib | 2 | 1,884 | 465 | 141 | 2,490 |
| electron | 4 | 972 | 159 | 150 | 1,281 |
| encoding.js-2.0.0 | 23 | 16,233 | 1,062 | 1,340 | 18,635 |
| encoding.js-2.0.0 (Files) | 9 | 9,771 | 519 | 738 | 11,028 |
| encoding.js-2.0.0\\src | 12 | 5,132 | 512 | 417 | 6,061 |
| encoding.js-2.0.0\\tests | 2 | 1,330 | 31 | 185 | 1,546 |
| encoding.js-master | 24 | 16,319 | 1,063 | 1,342 | 18,724 |
| encoding.js-master (Files) | 10 | 9,857 | 520 | 740 | 11,117 |
| encoding.js-master\\src | 12 | 5,132 | 512 | 417 | 6,061 |
| encoding.js-master\\tests | 2 | 1,330 | 31 | 185 | 1,546 |
| js | 5 | 1,172 | 404 | 260 | 1,836 |
| lib | 1 | 1 | 7 | 0 | 8 |
| plugins | 62 | 37,015 | 7,781 | 6,690 | 51,486 |
| plugins (Files) | 1 | 83 | 0 | 33 | 116 |
| plugins\\base-file-manager | 5 | 719 | 120 | 117 | 956 |
| plugins\\basic-figure-editor | 8 | 7,110 | 1,178 | 1,280 | 9,568 |
| plugins\\basic-text-editor | 5 | 5,757 | 1,336 | 1,112 | 8,205 |
| plugins\\existing-data-exec | 5 | 232 | 42 | 39 | 313 |
| plugins\\system-config | 5 | 734 | 66 | 125 | 925 |
| plugins\\tadjs-view | 5 | 6,639 | 2,060 | 1,436 | 10,135 |
| plugins\\trash-real-objects | 4 | 576 | 50 | 115 | 741 |
| plugins\\unpack-file | 9 | 9,615 | 1,801 | 1,394 | 12,810 |
| plugins\\url-link-exec | 5 | 240 | 25 | 43 | 308 |
| plugins\\user-config | 5 | 719 | 59 | 100 | 878 |
| plugins\\virtual-object-list | 5 | 4,591 | 1,044 | 896 | 6,531 |
| scripts | 1 | 25 | 10 | 12 | 47 |
| xtaddata | 6 | 263 | 0 | 1 | 264 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)