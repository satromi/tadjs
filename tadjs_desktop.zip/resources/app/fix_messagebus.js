const fs = require('fs');

// ファイルを読み込む
let content = fs.readFileSync('tadjs-desktop.js', 'utf8');

// パターン1: if (this.parentMessageBus) { respondTo(...) } else { console.warn(...) }
// 改行やインデントに対応するため、複数回実行
for (let i = 0; i < 10; i++) {
    content = content.replace(
        /if \(this\.parentMessageBus\) \{\s*this\.parentMessageBus\.(respondTo|sendToWindow|broadcast|registerChild|unregisterChild)\(/g,
        'this.parentMessageBus.$1('
    );

    content = content.replace(
        /\} else \{\s*console\.warn\('\[TADjs\] MessageBus未初期化:[^']+'\);\s*\}/g,
        '}'
    );
}

// 余分な空行を削除
content = content.replace(/\n\s*\}\s*\n\s*\}/g, '\n        }');

// ファイルに書き込む
fs.writeFileSync('tadjs-desktop.js', content, 'utf8');

console.log('置換完了');
