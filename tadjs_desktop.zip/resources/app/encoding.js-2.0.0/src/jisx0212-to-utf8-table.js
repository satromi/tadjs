/**
 * Encoding conversion table for JIS X 0212:1990 (Hojo-Kanji) to UTF-8
 */
var JISX0212_TO_UTF8_TABLE = null;
module.exports = JISX0212_TO_UTF8_TABLE;
