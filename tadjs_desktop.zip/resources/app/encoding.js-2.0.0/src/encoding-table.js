exports.UTF8_TO_JIS_TABLE = require('./utf8-to-jis-table');
exports.UTF8_TO_JISX0212_TABLE = require('./utf8-to-jisx0212-table');
exports.JIS_TO_UTF8_TABLE = require('./jis-to-utf8-table');
exports.JISX0212_TO_UTF8_TABLE = require('./jisx0212-to-utf8-table');
