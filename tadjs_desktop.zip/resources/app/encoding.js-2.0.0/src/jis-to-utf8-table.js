/**
 * Encoding conversion table for JIS to UTF-8
 */
var JIS_TO_UTF8_TABLE = null;
module.exports = JIS_TO_UTF8_TABLE;
