/*!
 * <%= pkg.name %> v<%= pkg.version %> - <%= pkg.description %>
 * Copyright (c) 2012 <%= pkg.author %>
 * <%= pkg.homepage %>
 * @license <%= pkg.license %>
 */
