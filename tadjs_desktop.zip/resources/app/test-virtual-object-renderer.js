/**
 * VirtualObjectRenderer ユニットテスト (Node.js環境)
 *
 * 使用方法:
 *   node test-virtual-object-renderer.js
 *
 * 注意: DOM/Canvas操作のテストは test-virtual-object-renderer.html で実施
 */

import { VirtualObjectRenderer } from './js/virtual-object-renderer.js';

let passCount = 0;
let failCount = 0;

function log(message, isError = false) {
    if (isError) {
        console.error(`✗ ${message}`);
        failCount++;
    } else {
        console.log(`✓ ${message}`);
        passCount++;
    }
}

function assert(condition, message) {
    if (condition) {
        log(message);
    } else {
        log(message, true);
    }
}

console.log('=== VirtualObjectRenderer ユニットテスト ===\n');

// テスト用の仮身オブジェクト
const testVirtualObjects = {
    basic: {
        id: '12345678-1234-7123-8123-123456789abc',
        name: 'テスト仮身',
        tbcol: '#e3f2fd',
        frcol: '#64b5f6',
        chcol: '#000000',
        bgcol: '#ffffff',
        chsz: 14
    },
    customColors: {
        id: '87654321-4321-7321-8321-cba987654321',
        name: 'カスタム色仮身',
        tbcol: '#fff3e0',
        frcol: '#ff9800',
        chcol: '#e65100',
        bgcol: '#fffde7',
        chsz: 16
    },
    opened: {
        id: 'aaaaaaaa-aaaa-7aaa-8aaa-aaaaaaaaaaaa',
        name: '開いた仮身',
        tbcol: '#f3e5f5',
        frcol: '#9c27b0',
        chcol: '#4a148c',
        bgcol: '#ffffff',
        chsz: 14,
        opened: true,
        realObjectId: 'bbbbbbbb-bbbb-7bbb-8bbb-bbbbbbbbbbbb',
        update: '2025-10-27 10:30:00'
    },
    minimal: {
        id: 'minimal-id',
        name: '最小仮身'
        // 色情報なし（デフォルト値を使用）
    }
};

// テスト1: コンストラクタ
console.log('1. コンストラクタとデフォルトスタイル');
try {
    const renderer = new VirtualObjectRenderer();
    assert(renderer !== null, 'VirtualObjectRenderer インスタンス作成成功');
    assert(renderer.defaultStyles.tbcol === '#e3f2fd', 'デフォルトtbcol設定確認');
    assert(renderer.defaultStyles.frcol === '#64b5f6', 'デフォルトfrcol設定確認');
    assert(renderer.defaultStyles.chsz === 14, 'デフォルトchsz設定確認');

    const customRenderer = new VirtualObjectRenderer({
        defaultStyles: { tbcol: '#ff0000', chsz: 20 }
    });
    assert(customRenderer.defaultStyles.tbcol === '#ff0000', 'カスタムtbcol設定確認');
    assert(customRenderer.defaultStyles.chsz === 20, 'カスタムchsz設定確認');
    assert(customRenderer.defaultStyles.frcol === '#64b5f6', 'その他のデフォルト値保持確認');
} catch (e) {
    log(`エラー: ${e.message}`, true);
}
console.log('');

// テスト2: getStyles()
console.log('2. getStyles() メソッド');
try {
    const renderer = new VirtualObjectRenderer();

    const styles = renderer.getStyles(testVirtualObjects.basic);
    assert(styles.tbcol === '#e3f2fd', '基本仮身のtbcol取得');
    assert(styles.frcol === '#64b5f6', '基本仮身のfrcol取得');
    assert(styles.chcol === '#000000', '基本仮身のchcol取得');
    assert(styles.bgcol === '#ffffff', '基本仮身のbgcol取得');
    assert(styles.chsz === 14, '基本仮身のchsz取得');

    const customStyles = renderer.getStyles(testVirtualObjects.customColors);
    assert(customStyles.tbcol === '#fff3e0', 'カスタム色仮身のtbcol取得');
    assert(customStyles.frcol === '#ff9800', 'カスタム色仮身のfrcol取得');
    assert(customStyles.chsz === 16, 'カスタム色仮身のchsz取得');

    const minimalStyles = renderer.getStyles(testVirtualObjects.minimal);
    assert(minimalStyles.tbcol === renderer.defaultStyles.tbcol, 'デフォルト値フォールバック（tbcol）');
    assert(minimalStyles.frcol === renderer.defaultStyles.frcol, 'デフォルト値フォールバック（frcol）');
    assert(minimalStyles.chsz === renderer.defaultStyles.chsz, 'デフォルト値フォールバック（chsz）');
} catch (e) {
    log(`エラー: ${e.message}`, true);
}
console.log('');

// テスト3: calculateSize()
console.log('3. calculateSize() メソッド');
try {
    const renderer = new VirtualObjectRenderer();

    const closedSize = renderer.calculateSize(testVirtualObjects.basic, 'closed');
    assert(closedSize.width > 0, `閉じた仮身の幅計算 (${closedSize.width}px)`);
    assert(closedSize.height > 0, `閉じた仮身の高さ計算 (${closedSize.height}px)`);

    const openedSize = renderer.calculateSize(testVirtualObjects.opened, 'opened');
    assert(openedSize.width > 0, `開いた仮身の幅計算 (${openedSize.width}px)`);
    assert(openedSize.height > 0, `開いた仮身の高さ計算 (${openedSize.height}px)`);

    assert(openedSize.height > closedSize.height, '開いた仮身は閉じた仮身より高い');
    assert(openedSize.width >= closedSize.width, '開いた仮身の幅は閉じた仮身以上');

    // カスタムサイズ
    const customSize = renderer.calculateSize({
        ...testVirtualObjects.basic,
        chsz: 20
    }, 'closed');
    assert(customSize.height >= 20, 'カスタム文字サイズ反映確認');
} catch (e) {
    log(`エラー: ${e.message}`, true);
}
console.log('');

// テスト4: isOpenedVirtualObject()
console.log('4. isOpenedVirtualObject() メソッド');
try {
    const renderer = new VirtualObjectRenderer();

    assert(!renderer.isOpenedVirtualObject(testVirtualObjects.basic), '閉じた仮身判定（基本）');
    assert(!renderer.isOpenedVirtualObject(testVirtualObjects.customColors), '閉じた仮身判定（カスタム色）');
    assert(renderer.isOpenedVirtualObject(testVirtualObjects.opened), '開いた仮身判定');

    // opened=falseの場合
    const explicitClosed = { ...testVirtualObjects.basic, opened: false };
    assert(!renderer.isOpenedVirtualObject(explicitClosed), 'opened=false判定');

    // openedプロパティがundefinedの場合
    const noOpenedProperty = { id: 'test', name: 'test' };
    assert(!renderer.isOpenedVirtualObject(noOpenedProperty), 'openedプロパティなし判定');
} catch (e) {
    log(`エラー: ${e.message}`, true);
}
console.log('');

// テスト5: オプションパラメータ
console.log('5. オプションパラメータの動作確認');
try {
    const renderer = new VirtualObjectRenderer();

    // showNameオプション
    const sizeWithName = renderer.calculateSize(testVirtualObjects.basic, 'closed');
    const sizeWithoutName = renderer.calculateSize(testVirtualObjects.basic, 'closed');
    assert(sizeWithName.width > 0 && sizeWithoutName.width > 0, 'showNameオプション影響確認');

    // 複数オプションの組み合わせ
    const multiOptionSize = renderer.calculateSize(testVirtualObjects.opened, 'opened');
    assert(multiOptionSize.width > 0 && multiOptionSize.height > 0, '複数オプション組み合わせ');
} catch (e) {
    log(`エラー: ${e.message}`, true);
}
console.log('');

// テスト6: エッジケース
console.log('6. エッジケースのテスト');
try {
    const renderer = new VirtualObjectRenderer();

    // 空の仮身オブジェクト
    const emptyStyles = renderer.getStyles({});
    assert(emptyStyles.tbcol === renderer.defaultStyles.tbcol, '空オブジェクトでデフォルト値使用');

    // 無効なchszの処理
    const invalidChszObj = { id: 'test', name: 'test', chsz: 'invalid' };
    const invalidChszStyles = renderer.getStyles(invalidChszObj);
    assert(!isNaN(invalidChszStyles.chsz), '無効なchsz値の処理');

    // nullやundefinedのプロパティ
    const nullPropsObj = { id: 'test', name: 'test', tbcol: null, chsz: undefined };
    const nullPropsStyles = renderer.getStyles(nullPropsObj);
    assert(nullPropsStyles.tbcol === renderer.defaultStyles.tbcol, 'nullプロパティでデフォルト値使用');
    assert(nullPropsStyles.chsz === renderer.defaultStyles.chsz, 'undefinedプロパティでデフォルト値使用');
} catch (e) {
    log(`エラー: ${e.message}`, true);
}
console.log('');

// テスト7: 異なる文字サイズの処理
console.log('7. 文字サイズバリエーション');
try {
    const renderer = new VirtualObjectRenderer();

    const sizes = [10, 12, 14, 16, 18, 20, 24];
    let prevHeight = 0;

    sizes.forEach(size => {
        const obj = { ...testVirtualObjects.basic, chsz: size };
        const calcSize = renderer.calculateSize(obj, 'closed');
        assert(calcSize.height >= prevHeight, `文字サイズ${size}px時の高さが単調増加`);
        prevHeight = calcSize.height;
    });
} catch (e) {
    log(`エラー: ${e.message}`, true);
}
console.log('');

// サマリー表示
console.log('=== テスト結果サマリー ===');
const total = passCount + failCount;
const successRate = total > 0 ? ((passCount / total) * 100).toFixed(1) : 0;

console.log(`合計: ${total} テスト`);
console.log(`成功: ${passCount} (${successRate}%)`);
console.log(`失敗: ${failCount}`);

if (failCount === 0) {
    console.log('\n✓ すべてのテストに合格しました!');
} else {
    console.log(`\n✗ ${failCount}件のテストが失敗しました`);
    process.exit(1);
}
