import js from "@eslint/js";

export default [
    js.configs.recommended,
    {
        languageOptions: {
            ecmaVersion: "latest",
            sourceType: "script",
            globals: {
                console: "readonly",
                window: "writable",
                document: "readonly",
                Encoding: "readonly",
                FileReader: "readonly",
                DataView: "readonly",
                Uint8Array: "readonly",
                ArrayBuffer: "readonly",
                Float32Array: "readonly",
                setTimeout: "readonly",
                clearTimeout: "readonly",
                setInterval: "readonly",
                clearInterval: "readonly",
                HTMLCanvasElement: "readonly",
                HTMLElement: "readonly",
                Event: "readonly",
                File: "readonly",
                FileList: "readonly",
                DragEvent: "readonly",
                MouseEvent: "readonly",
                KeyboardEvent: "readonly",
                Image: "readonly",
                XMLHttpRequest: "readonly",
                Blob: "readonly",
                URL: "readonly",
                module: "writable",
                exports: "writable",
                require: "readonly",
                process: "readonly",
                Buffer: "readonly",
                TextDecoder: "readonly",
                LH5Decoder: "readonly",
                alert: "readonly"
            }
        },
        rules: {
            "no-unused-vars": ["error", { 
                "args": "none", 
                "varsIgnorePattern": "^_",
                "argsIgnorePattern": "^_",
                "caughtErrorsIgnorePattern": "^_"
            }],
            "no-console": "off",
            "no-constant-condition": "off",
            "no-empty": "off",
            "prefer-const": "warn",
            "no-var": "warn",
            "no-undef": "error"
        }
    }
];