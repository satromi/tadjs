# 開発メモ

## nulファイル生成の問題と対策

### 問題
BashシェルでWindowsコマンドを実行する際、`2>nul` のようなリダイレクトを使用すると、Windowsの `NUL` デバイスではなく通常のファイル `nul` が作成されてしまう。

### 原因
- Bashシェル: `nul` を通常のファイル名として解釈
- Windowsコマンドプロンプト: `nul` を特殊デバイス（/dev/null相当）として解釈

### 対策

#### 1. .gitignoreに追加 ✅
```
nul
```

#### 2. コマンド実行時の方針

**推奨方法A: エラー出力を削除しない**
```bash
# Good (Bash)
mkdir -p backup/baseline-20251128
```

**推奨方法B: /dev/nullを使用**
```bash
# Good (Bash)
mkdir -p backup/baseline-20251128 2>/dev/null
```

**非推奨: 2>nul を使用しない**
```bash
# Bad (creates 'nul' file in Bash)
cmd /c "mkdir backup\baseline-20251128 2>nul"
```

**代替案: PowerShellを使用**
```bash
# Good (PowerShell)
powershell -Command "New-Item -ItemType Directory -Force -Path backup\baseline-20251128 -ErrorAction SilentlyContinue"
```

#### 3. 既存のnulファイルの削除

```bash
# Bashで削除
rm -f nul

# PowerShellで削除
powershell -Command "Remove-Item nul -ErrorAction SilentlyContinue"
```

### 今後のガイドライン

1. **Bashコマンド使用時**: `/dev/null` を使用
2. **Windowsコマンド使用時**: `cmd /c` は避け、PowerShellまたはBashネイティブコマンドを使用
3. **エラー抑制が不要な場合**: リダイレクトを削除

---

**作成日**: 2025-11-28
**更新日**: 2025-11-28
