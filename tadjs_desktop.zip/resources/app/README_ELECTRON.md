# BTRON Desktop - Electron版

TAD.jsをベースにしたBTRONデスクトップ環境のElectronアプリケーション版です。
プラグインシステムを搭載し、「基本文章編集」リッチテキストエディタプラグインが含まれています。

## 機能概要

### コア機能
- ✅ Electronベースのデスクトップアプリケーション
- ✅ プラグインシステム(VSCode/Obsidian風)
- ✅ TADファイルのドラッグ&ドロップ表示
- ✅ 右クリックメニューからのプラグイン起動
- ✅ ウィンドウ管理システム

### 基本文章編集プラグイン
- ✅ TADファイルのリッチテキスト編集
- ✅ tadXML読み込み・解析
- ✅ 文字装飾(太字・斜体・下線)
- ✅ テキスト配置(左・中央・右)
- ✅ フォント・サイズ変更
- ✅ XML形式でのエクスポート
- ✅ ファイル保存機能

## セットアップ手順

### 1. 依存パッケージのインストール

```bash
npm install
```

### 2. ブラウザ版で動作確認

```bash
# HTTPサーバを起動(ポート8000)
npm run serve
# または
npx http-server -p 8000
```

ブラウザで http://127.0.0.1:8000/btron-desktop.html にアクセス

### 3. Electron版で起動

```bash
# 開発モード(DevToolsが開く)
npm run dev

# 通常起動
npm start
```

### 4. アプリケーションのビルド

```bash
npm run build
```

ビルドされたアプリは`dist/`ディレクトリに出力されます。

## ディレクトリ構成

```
tadjs/
├── electron/                    # Electronメインプロセス
│   ├── main.js                 # メインプロセス
│   ├── preload.js              # プレロードスクリプト
│   └── plugin-manager.js       # プラグインマネージャー(レンダラー用)
│
├── plugins/                     # プラグインディレクトリ
│   └── basic-text-editor/      # 基本文章編集プラグイン
│       ├── plugin.json         # プラグイン定義
│       ├── index.html          # エディタUI
│       ├── style.css           # スタイル
│       └── editor.js           # エディタロジック
│
├── btron-desktop.html          # メインHTML
├── btron-desktop.js            # デスクトップ環境ロジック
├── btron-desktop.css           # スタイル
├── tad.js                      # TADパーサー
├── package.json                # パッケージ定義
└── README_ELECTRON.md          # このファイル
```

## 使い方

### TADファイルを開く

1. BTRONデスクトップを起動
2. TADファイルをウィンドウにドラッグ&ドロップ
3. ファイルアイコンが表示される

### 基本文章編集プラグインを使用

1. TADファイルアイコンを右クリック
2. 右クリックメニューから「基本文章編集」を選択
3. リッチテキストエディタが起動
4. 編集後、「保存」または「XMLエクスポート」で保存

### キーボードショートカット(エディタ内)

- `Ctrl+S`: 保存
- `Ctrl+B`: 太字
- `Ctrl+I`: 斜体
- `Ctrl+U`: 下線

## プラグイン開発

### プラグインの作成

1. `plugins/`ディレクトリに新しいフォルダを作成
2. `plugin.json`を作成:

```json
{
  "id": "my-plugin",
  "name": "マイプラグイン",
  "version": "1.0.0",
  "description": "プラグインの説明",
  "main": "index.html",
  "contextMenu": [
    {
      "label": "マイプラグインで開く",
      "fileTypes": ["tad", "TAD"],
      "action": "open-with-plugin"
    }
  ]
}
```

3. `index.html`を作成してプラグインUIを実装
4. Electronを再起動すると自動的に読み込まれます

### プラグインAPI

プラグインは親ウィンドウから`postMessage`でデータを受信:

```javascript
window.addEventListener('message', (event) => {
    if (event.data.type === 'plugin-init') {
        const pluginId = event.data.pluginId;
        const fileData = event.data.fileData;
        // ファイルデータを処理
    }
});
```

## トラブルシューティング

### プラグインが表示されない

1. `plugins/`ディレクトリの存在を確認
2. `plugin.json`の構文エラーを確認
3. Electronを再起動

### ファイルが開けない

1. ファイルが正しいTAD形式か確認
2. ブラウザのコンソールでエラーメッセージを確認
3. `tad.js`の読み込みを確認

## ライセンス

MIT License

## 開発者向け情報

### Electron IPC通信

メインプロセスとレンダラープロセス間の通信:

- `get-plugins`: プラグイン一覧取得
- `get-plugin`: 特定プラグイン取得
- `open-file-dialog`: ファイル選択ダイアログ
- `save-file-dialog`: 保存ダイアログ
- `save-file`: ファイル保存
- `read-file`: ファイル読み込み

### デバッグモード

```bash
npm run dev
```

DevToolsが自動的に開き、コンソールログを確認できます。
