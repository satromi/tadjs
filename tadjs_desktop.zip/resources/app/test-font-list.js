const fontList = require('font-list');

console.log('=== font-list ライブラリのテスト ===\n');

// オプションなしで取得
fontList.getFonts()
    .then(fonts => {
        console.log(`取得したフォント数: ${fonts.length}`);
        console.log('\n--- 最初の10件 ---');
        fonts.slice(0, 10).forEach((font, i) => {
            console.log(`${i + 1}. ${font}`);
        });

        // 玉ねぎフォントを検索
        console.log('\n--- 玉ねぎフォント検索 (Tamanegi) ---');
        const tamanegiEnglish = fonts.filter(f =>
            f.toLowerCase().includes('tamanegi')
        );
        if (tamanegiEnglish.length > 0) {
            console.log('英語名で見つかりました:');
            tamanegiEnglish.forEach(f => console.log(`  - ${f}`));
        } else {
            console.log('英語名では見つかりませんでした');
        }

        // 玉ねぎフォントを日本語で検索
        console.log('\n--- 玉ねぎフォント検索 (日本語) ---');
        const tamanegiJapanese = fonts.filter(f =>
            f.includes('玉ねぎ') || f.includes('タマネギ')
        );
        if (tamanegiJapanese.length > 0) {
            console.log('日本語名で見つかりました:');
            tamanegiJapanese.forEach(f => console.log(`  - ${f}`));
        } else {
            console.log('日本語名では見つかりませんでした');
        }

        // 日本語を含むフォントを検索
        console.log('\n--- 日本語を含むフォント（最初の20件） ---');
        const japaneseFonts = fonts.filter(f => /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]/.test(f));
        console.log(`日本語フォント数: ${japaneseFonts.length}`);
        japaneseFonts.slice(0, 20).forEach(f => {
            console.log(`  - ${f}`);
        });
    })
    .catch(err => {
        console.error('エラー:', err);
    });

// disableQuoting オプション付きでも試す
console.log('\n\n=== disableQuoting: true オプション付き ===\n');
fontList.getFonts({ disableQuoting: true })
    .then(fonts => {
        console.log(`取得したフォント数: ${fonts.length}`);

        console.log('\n--- 玉ねぎフォント検索 ---');
        const tamanegi = fonts.filter(f =>
            f.toLowerCase().includes('tamanegi') ||
            f.includes('玉ねぎ') ||
            f.includes('タマネギ')
        );
        if (tamanegi.length > 0) {
            console.log('見つかりました:');
            tamanegi.forEach(f => console.log(`  - ${f}`));
        } else {
            console.log('見つかりませんでした');
        }
    })
    .catch(err => {
        console.error('エラー:', err);
    });
