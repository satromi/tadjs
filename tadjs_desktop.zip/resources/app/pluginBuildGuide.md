# TADjs Desktop プラグイン開発ガイド

このドキュメントは、TADjs Desktopのプラグインを開発するための包括的なガイドです。基本文章編集プラグインと仮身一覧プラグインを題材に、プラグインの構造、メッセージ通信、ファイル構成などを詳しく解説します。

## 目次

1. [プラグインの基本構造](#プラグインの基本構造)
2. [フォルダ構成](#フォルダ構成)
3. [必須ファイル](#必須ファイル)
4. [plugin.json 仕様](#pluginjson-仕様)
5. [メッセージ通信](#メッセージ通信)
6. [ライフサイクル](#ライフサイクル)
7. [実身仮身システムとの連携](#実身仮身システムとの連携)
8. [メニューシステム](#メニューシステム)
9. [道具パネル](#道具パネル)
10. [ベストプラクティス](#ベストプラクティス)
11. [実装例](#実装例)

---

## プラグインの基本構造

TADjs Desktopのプラグインは、HTMLベースのWebアプリケーションとして実装されます。プラグインはiframe内で実行され、親ウィンドウ（tadjs-desktop.js）とpostMessageを使って通信します。

### プラグインの種類

- **baseプラグイン**: 基本機能を提供するプラグイン（編集、表示など）
- **toolプラグイン**: 補助的なツールを提供するプラグイン（パレット、道具箱など）

---

## フォルダ構成

### 基本的なフォルダ構成

```
plugins/
└── your-plugin/
    ├── plugin.json              # プラグインのメタデータ（必須）
    ├── index.html               # エントリーポイント（必須）
    ├── style.css                # スタイルシート
    ├── app.js または editor.js  # メインロジック
    ├── [実身ID].json            # 原紙ファイル（basefileとして登録）
    ├── [実身ID]_0.xtad          # 原紙のXMLTAD
    └── [実身ID].ico             # 原紙のアイコン
```

### 実例

#### 基本文章編集プラグイン
```
plugins/basic-text-editor/
├── plugin.json
├── index.html
├── style.css
├── editor.js
├── 019a1132-762b-7b02-ba2a-a918a9b37c39.json
├── 019a1132-762b-7b02-ba2a-a918a9b37c39_0.xtad
└── 019a1132-762b-7b02-ba2a-a918a9b37c39.ico
```

#### 仮身一覧プラグイン
```
plugins/virtual-object-list/
├── plugin.json
├── index.html
├── style.css
├── app.js
├── 0199ce60-532a-7670-b8bc-84c970de11dc.json
├── 0199ce60-532a-7670-b8bc-84c970de11dc_0.xtad
└── 0199ce60-532a-7670-b8bc-84c970de11dc.ico
```

---

## 必須ファイル

### 1. plugin.json

プラグインのメタデータを定義するJSONファイル。プラグインマネージャーがこのファイルを読み込んでプラグインを認識します。

### 2. index.html

プラグインのエントリーポイント。iframe内で読み込まれるHTMLファイルです。

#### 基本的な構造

```html
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>プラグイン名</title>
    <link rel="stylesheet" href="style.css">
</head>
<body tabindex="0">
    <div class="plugin-content">
        <!-- プラグインのUI -->
    </div>

    <!-- 共通ユーティリティをグローバル変数として読み込み -->
    <script type="module">
        import { VirtualObjectRenderer } from '../../js/virtual-object-renderer.js';
        window.VirtualObjectRenderer = VirtualObjectRenderer;
    </script>
    <script type="module">
        import { convertPtToPx } from '../../js/util.js';
        window.convertPtToPx = convertPtToPx;
    </script>
    <script type="module">
        import { debounce, throttle, throttleRAF } from '../../js/performance-utils.js';
        window.debounce = debounce;
        window.throttle = throttle;
        window.throttleRAF = throttleRAF;
    </script>
    <script defer src="app.js"></script>
</body>
</html>
```

### 3. メインスクリプト (app.js / editor.js)

プラグインのメインロジックを実装するJavaScriptファイル。

---

## plugin.json 仕様

### 基本構造

```json
{
  "id": "plugin-id",
  "name": "プラグイン名",
  "version": "1.0.0",
  "type": "base",
  "basefile": {
    "json": "実身ID.json",
    "xmltad": "実身ID_0.xtad",
    "ico": "実身ID.ico"
  },
  "description": "プラグインの説明",
  "icon": "📋",
  "author": "作者名",
  "main": "index.html",
  "needsCloseConfirmation": true,
  "window": {
    "width": 800,
    "height": 600,
    "resizable": true,
    "scrollable": true,
    "openable": true
  },
  "contextMenu": [
    {
      "label": "メニューラベル",
      "fileTypes": ["tad", "TAD", "xtad", "XTAD"],
      "action": "open-editor"
    }
  ],
  "permissions": [
    "file-read",
    "file-write"
  ]
}
```

### フィールド詳細

#### 必須フィールド

- **id**: プラグインの一意な識別子（英数字とハイフン）
- **name**: プラグインの表示名
- **version**: バージョン（セマンティックバージョニング推奨）
- **type**: プラグインタイプ（`base` または `tool`）
- **main**: エントリーポイントのHTMLファイル

#### オプションフィールド

- **basefile**: 原紙ファイルの情報
  - `json`: 実身メタデータファイル
  - `xmltad`: 実身のXMLTADファイル
  - `ico`: アイコンファイル
- **description**: プラグインの説明
- **icon**: プラグインのアイコン（絵文字推奨）
- **author**: 作者名
- **needsCloseConfirmation**: 閉じる前に確認ダイアログを表示するか（boolean）
- **window**: ウィンドウの初期設定
  - `width`: 幅（ピクセル）
  - `height`: 高さ（ピクセル）
  - `resizable`: リサイズ可能か（boolean）
  - `scrollable`: スクロール可能か（boolean）
  - `openable`: 仮身を開くことができるか（boolean）
- **contextMenu**: コンテキストメニューの定義
  - `label`: メニューラベル
  - `fileTypes`: 対象ファイルタイプ（拡張子の配列）
  - `action`: アクション名
- **permissions**: 必要な権限
  - `file-read`: ファイル読み込み
  - `file-write`: ファイル書き込み

---

## メッセージ通信

プラグインは親ウィンドウ（tadjs-desktop.js）とpostMessageを使って通信します。

### メッセージの基本構造

```javascript
// プラグインから親ウィンドウへ
window.parent.postMessage({
    type: 'メッセージタイプ',
    // 追加データ
}, '*');

// 親ウィンドウからプラグインへ
window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'メッセージタイプ') {
        // 処理
    }
});
```

### 親ウィンドウからプラグインへのメッセージ

#### 1. init（初期化）

プラグインが読み込まれた直後に送信されます。

```javascript
{
    type: 'init',
    pluginId: 'plugin-id',
    windowId: 'window_1',
    fileData: {
        realId: '実身ID',
        fileId: '実身ID_0.xtad',
        fileName: 'ファイル名',
        xmlData: 'XML文字列',
        rawData: [バイト配列],
        displayName: '表示名',
        windowConfig: {
            pos: { x: 100, y: 100 },
            width: 800,
            height: 600,
            backgroundColor: '#ffffff'
        },
        readonly: false,
        noScrollbar: false,
        bgcol: '#ffffff'
    }
}
```

**実装例:**

```javascript
window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'init') {
        console.log('[Plugin] init受信');

        // realIdを保存（拡張子を除去）
        if (event.data.fileData) {
            let rawId = event.data.fileData.realId || event.data.fileData.fileId;
            this.realId = rawId ? rawId.replace(/_\d+\.xtad$/i, '') : null;
        }

        // ファイルを読み込む
        this.loadFile(event.data.fileData);
    }
});
```

#### 2. window-moved（ウィンドウ移動）

ウィンドウが移動された後に送信されます。

```javascript
{
    type: 'window-moved',
    pos: { x: 150, y: 200 },
    width: 800,
    height: 600
}
```

#### 3. window-resized-end（ウィンドウリサイズ終了）

ウィンドウのリサイズが終了した後に送信されます。

```javascript
{
    type: 'window-resized-end',
    pos: { x: 100, y: 100 },
    width: 1000,
    height: 700
}
```

#### 4. menu-action（メニューアクション）

メニューが選択された時に送信されます。

```javascript
{
    type: 'menu-action',
    action: 'save',
    additionalData: { ... }
}
```

#### 5. get-menu-definition（メニュー定義要求）

親ウィンドウがプラグインのメニュー定義を要求します。

```javascript
{
    type: 'get-menu-definition'
}
```

**実装例:**

```javascript
if (event.data && event.data.type === 'get-menu-definition') {
    this.getMenuDefinition().then(menuDefinition => {
        window.parent.postMessage({
            type: 'menu-definition',
            menuDefinition: menuDefinition
        }, '*');
    });
}
```

#### 6. drop-virtual-object（仮身ドロップ）

仮身がプラグインにドロップされた時に送信されます。

```javascript
{
    type: 'drop-virtual-object',
    virtualObjects: [{
        link_id: '実身ID_0.xtad',
        link_name: '実身名',
        // その他のプロパティ
    }],
    dropPosition: { x: 100, y: 200 }
}
```

### プラグインから親ウィンドウへのメッセージ

#### 1. menu-definition（メニュー定義）

プラグインのメニュー定義を親ウィンドウに送信します。

```javascript
window.parent.postMessage({
    type: 'menu-definition',
    menuDefinition: [
        {
            label: 'ファイル',
            submenu: [
                { label: '保存', action: 'save', shortcut: 'Ctrl+S' },
                { separator: true },
                { label: '閉じる', action: 'close' }
            ]
        },
        {
            label: '編集',
            submenu: [
                { label: 'コピー', action: 'copy', shortcut: 'Ctrl+C' },
                { label: '貼り付け', action: 'paste', shortcut: 'Ctrl+V' }
            ]
        }
    ]
}, '*');
```

#### 2. xml-data-changed（XMLデータ変更通知）

プラグインがXMLデータを変更した時に親ウィンドウに通知します。

```javascript
window.parent.postMessage({
    type: 'xml-data-changed',
    realId: '実身ID',
    xmlData: '更新されたXML文字列'
}, '*');
```

#### 3. scroll-update（スクロールバー更新要求）

プラグインの内容が変更され、スクロールバーの更新が必要な時に送信します。

```javascript
window.parent.postMessage({
    type: 'scroll-update',
    direction: 'vertical', // または 'horizontal'
    scrollHeight: 1000,
    scrollWidth: 800,
    clientHeight: 600,
    clientWidth: 800
}, '*');
```

#### 4. open-real-object（実身を開く）

仮身をダブルクリックして実身を開く時に送信します。

```javascript
window.parent.postMessage({
    type: 'open-real-object',
    linkId: '実身ID_0.xtad',
    linkName: '実身名',
    realId: '実身ID',
    pos: { x: 150, y: 150 }
}, '*');
```

#### 5. close-confirmation-result（閉じる確認結果）

閉じる確認ダイアログの結果を送信します。

```javascript
window.parent.postMessage({
    type: 'close-confirmation-result',
    result: 'save' // 'save', 'discard', 'cancel'
}, '*');
```

#### 6. base-file-drop-request（原紙ドロップ要求）

原紙箱から原紙をドロップした時に、親ウィンドウに処理を委譲します。

```javascript
window.parent.postMessage({
    type: 'base-file-drop-request',
    basefile: {
        pluginId: 'basic-figure-editor',
        json: '...',
        xtad: '...',
        ico: '...'
    },
    dropPosition: { x: 100, y: 200 }
}, '*');
```

#### 7. show-context-menu（コンテキストメニュー表示要求）

右クリック時にコンテキストメニューを表示する要求を送信します。

```javascript
window.parent.postMessage({
    type: 'show-context-menu',
    menuItems: [
        { label: 'コピー', action: 'copy' },
        { separator: true },
        { label: '削除', action: 'delete' }
    ],
    position: { x: 100, y: 200 }
}, '*');
```

#### 8. open-tool-panel（道具パネルを開く）

道具パネルウィンドウを開く要求を送信します（基本図形編集プラグインなど）。

```javascript
window.parent.postMessage({
    type: 'open-tool-panel',
    pluginId: 'basic-figure-editor',
    toolPanelConfig: {
        width: 200,
        height: 400
    }
}, '*');
```

---

## ライフサイクル

### 1. プラグイン読み込み

```
親ウィンドウ
  ↓ plugin.jsonを読み込み
  ↓ iframeを作成
  ↓ index.htmlを読み込み
プラグイン（iframe内）
  ↓ DOMContentLoaded
  ↓ スクリプト実行
  ↓ 初期化処理
```

### 2. 初期化

```javascript
class YourPlugin {
    constructor() {
        this.realId = null;
        this.isModified = false;
        this.init();
    }

    init() {
        // イベントリスナーの設定
        this.setupEventListeners();

        // 親ウィンドウからのメッセージを受信
        window.addEventListener('message', (event) => {
            this.handleMessage(event);
        });
    }

    handleMessage(event) {
        if (!event.data) return;

        switch (event.data.type) {
            case 'init':
                this.handleInit(event.data);
                break;
            case 'menu-action':
                this.executeMenuAction(event.data.action);
                break;
            // その他のメッセージタイプ
        }
    }

    handleInit(data) {
        if (data.fileData) {
            this.realId = data.fileData.realId;
            this.loadFile(data.fileData);
        }
    }
}

// DOMContentLoaded後に初期化
document.addEventListener('DOMContentLoaded', () => {
    new YourPlugin();
});
```

### 3. ファイル読み込み

```javascript
loadFile(fileData) {
    if (!fileData) {
        console.log('[Plugin] fileDataがありません');
        return;
    }

    if (fileData.xmlData) {
        // XMLデータをパースして表示
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(fileData.xmlData, 'text/xml');

        // ... 処理 ...
    }
}
```

### 4. データ保存

```javascript
saveData() {
    // データをXML形式に変換
    const xmlData = this.generateXML();

    // 親ウィンドウに変更を通知
    window.parent.postMessage({
        type: 'xml-data-changed',
        realId: this.realId,
        xmlData: xmlData
    }, '*');

    this.isModified = false;
}
```

### 5. クローズ

```javascript
// needsCloseConfirmation: true の場合
window.addEventListener('beforeunload', (event) => {
    if (this.isModified) {
        // 親ウィンドウに確認要求を送信
        window.parent.postMessage({
            type: 'request-close-confirmation'
        }, '*');

        event.preventDefault();
        event.returnValue = '';
    }
});
```

---

## 実身仮身システムとの連携

### 仮身のレンダリング

プラグインで仮身を表示する場合、`VirtualObjectRenderer`を使用します。

```javascript
// VirtualObjectRendererの初期化
if (window.VirtualObjectRenderer) {
    this.virtualObjectRenderer = new window.VirtualObjectRenderer();
}

// 仮身をレンダリング
const vobjElement = this.virtualObjectRenderer.render(virtualObject, {
    width: 150,
    height: 100,
    showIcon: true,
    showName: true
});

// DOM要素として追加
this.container.appendChild(vobjElement);
```

### 仮身のドロップ処理

```javascript
// ドラッグオーバー
this.container.addEventListener('dragover', (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
});

// ドロップ
this.container.addEventListener('drop', async (e) => {
    e.preventDefault();

    const data = e.dataTransfer.getData('text/plain');
    if (data) {
        try {
            const dragData = JSON.parse(data);

            if (dragData.type === 'virtual-object-drag') {
                const rect = this.container.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                const virtualObjects = dragData.virtualObjects || [dragData.virtualObject];

                virtualObjects.forEach((virtualObject) => {
                    this.insertVirtualObject(x, y, virtualObject);
                });

                // クロスウィンドウドロップ成功を通知
                if (window.parent && window.parent !== window) {
                    window.parent.postMessage({
                        type: 'cross-window-drop-success',
                        mode: dragData.mode,
                        source: dragData.source,
                        sourceWindowId: dragData.sourceWindowId,
                        virtualObjectId: virtualObjects[0].link_id
                    }, '*');
                }
            }
        } catch (error) {
            console.error('[Plugin] ドロップ処理エラー:', error);
        }
    }
});
```

### 仮身を開く

```javascript
openVirtualObject(virtualObject) {
    window.parent.postMessage({
        type: 'open-real-object',
        linkId: virtualObject.link_id,
        linkName: virtualObject.link_name,
        realId: virtualObject.link_id.replace(/_\d+\.xtad$/i, ''),
        pos: { x: 150, y: 150 }
    }, '*');
}
```

### アイコンの読み込み

```javascript
// アイコン読み込みを要求
window.parent.postMessage({
    type: 'read-icon-file',
    realId: realId
}, '*');

// アイコンデータを受信
window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'icon-file-loaded') {
        const { realId, data } = event.data;
        if (data) {
            // Base64データとして利用
            const iconUrl = `data:image/x-icon;base64,${data}`;
            // アイコンを表示
        }
    }
});
```

---

## メニューシステム

### メニュー定義

```javascript
async getMenuDefinition() {
    return [
        {
            label: 'ファイル',
            submenu: [
                {
                    label: '保存',
                    action: 'save',
                    shortcut: 'Ctrl+S',
                    disabled: !this.isModified
                },
                { separator: true },
                { label: '閉じる', action: 'close' }
            ]
        },
        {
            label: '編集',
            submenu: [
                { label: '元に戻す', action: 'undo', shortcut: 'Ctrl+Z' },
                { label: 'やり直す', action: 'redo', shortcut: 'Ctrl+Y' },
                { separator: true },
                { label: 'コピー', action: 'copy', shortcut: 'Ctrl+C' },
                { label: '貼り付け', action: 'paste', shortcut: 'Ctrl+V' },
                { label: '削除', action: 'delete', shortcut: 'Delete' }
            ]
        },
        {
            label: '表示',
            submenu: [
                {
                    label: '全画面表示',
                    action: 'toggle-fullscreen',
                    checked: this.isFullscreen
                }
            ]
        }
    ];
}
```

### メニューアクションの実行

```javascript
executeMenuAction(action, additionalData) {
    console.log('[Plugin] メニューアクション:', action);

    switch (action) {
        case 'save':
            this.save();
            break;
        case 'undo':
            this.undo();
            break;
        case 'redo':
            this.redo();
            break;
        case 'copy':
            this.copy();
            break;
        case 'paste':
            this.paste();
            break;
        case 'delete':
            this.delete();
            break;
        case 'toggle-fullscreen':
            this.toggleFullscreen();
            break;
        default:
            console.warn('[Plugin] 未知のアクション:', action);
    }
}
```

### キーボードショートカット

```javascript
setupEventListeners() {
    document.addEventListener('keydown', (e) => {
        // Ctrl+S: 保存
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            this.save();
        }

        // Ctrl+Z: 元に戻す
        if (e.ctrlKey && e.key === 'z') {
            e.preventDefault();
            this.undo();
        }

        // Ctrl+Y: やり直す
        if (e.ctrlKey && e.key === 'y') {
            e.preventDefault();
            this.redo();
        }

        // Delete: 削除
        if (e.key === 'Delete') {
            this.delete();
        }
    });
}
```

---

## 道具パネル

一部のプラグイン（基本図形編集など）は、道具パネルと呼ばれる補助ウィンドウを持つことができます。

### 道具パネルの開き方

```javascript
openToolPanel() {
    window.parent.postMessage({
        type: 'open-tool-panel',
        pluginId: 'your-plugin-id'
    }, '*');
}

// 道具パネルが作成されたことを受信
window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'tool-panel-created') {
        this.toolPanelWindowId = event.data.toolPanelWindowId;
        console.log('[Plugin] 道具パネル作成:', this.toolPanelWindowId);
    }
});
```

### 道具パネルとの通信

```javascript
// 親プラグインから道具パネルへメッセージを送信
sendMessageToToolPanel(message) {
    window.parent.postMessage({
        type: 'forward-to-tool-panel',
        targetWindowId: this.toolPanelWindowId,
        message: message
    }, '*');
}

// 道具パネルから親プラグインへメッセージを送信
// (tool-panel.jsで実行)
window.parent.postMessage({
    type: 'tool-selected',
    tool: 'rect',
    parentPluginId: 'basic-figure-editor'
}, '*');
```

### 道具パネルの実装例

```html
<!-- tool-panel/index.html -->
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>道具パネル</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="tool-panel">
        <button data-tool="select">選択</button>
        <button data-tool="rect">矩形</button>
        <button data-tool="ellipse">楕円</button>
        <button data-tool="line">直線</button>
    </div>
    <script src="tool-panel.js"></script>
</body>
</html>
```

```javascript
// tool-panel.js
class ToolPanel {
    constructor() {
        this.parentPluginId = null;
        this.init();
    }

    init() {
        // 親ウィンドウからのメッセージを受信
        window.addEventListener('message', (event) => {
            if (event.data && event.data.type === 'init') {
                this.parentPluginId = event.data.parentPluginId;
            }
        });

        // ツールボタンのクリックイベント
        document.querySelectorAll('[data-tool]').forEach(button => {
            button.addEventListener('click', () => {
                const tool = button.dataset.tool;
                this.selectTool(tool);
            });
        });
    }

    selectTool(tool) {
        // 親プラグインにツール選択を通知
        window.parent.postMessage({
            type: 'tool-selected',
            tool: tool,
            parentPluginId: this.parentPluginId
        }, '*');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new ToolPanel();
});
```

---

## ベストプラクティス

### 1. エラーハンドリング

```javascript
try {
    // 処理
} catch (error) {
    console.error('[Plugin] エラー:', error);
    // エラーメッセージを表示
    this.showError('エラーが発生しました: ' + error.message);
}
```

### 2. パフォーマンス最適化

```javascript
// デバウンス（入力イベントなど）
if (window.debounce) {
    this.debouncedSave = window.debounce(() => {
        this.save();
    }, 1000);
}

// スロットル（スクロールイベントなど）
if (window.throttle) {
    this.throttledScroll = window.throttle(() => {
        this.updateScrollbar();
    }, 100);
}
```

### 3. メモリ管理

```javascript
destroy() {
    // イベントリスナーの削除
    window.removeEventListener('message', this.messageHandler);

    // タイマーのクリア
    if (this.updateTimer) {
        clearTimeout(this.updateTimer);
    }

    // 大きなオブジェクトの削除
    this.data = null;
    this.cache.clear();
}
```

### 4. ログ出力

```javascript
// 統一されたログ形式
console.log('[YourPlugin] 処理開始');
console.error('[YourPlugin] エラー:', error);
console.warn('[YourPlugin] 警告:', warning);
```

### 5. 変更フラグの管理

```javascript
setModified(modified) {
    this.isModified = modified;

    // ウィンドウタイトルに変更マークを表示
    window.parent.postMessage({
        type: 'update-modified-state',
        modified: modified
    }, '*');
}
```

---

## 実装例

### 最小限のプラグイン

```javascript
// minimal-plugin/app.js
class MinimalPlugin {
    constructor() {
        this.realId = null;
        this.content = '';
        this.init();
    }

    init() {
        // メッセージリスナー
        window.addEventListener('message', (event) => {
            if (!event.data) return;

            switch (event.data.type) {
                case 'init':
                    this.handleInit(event.data);
                    break;
                case 'menu-action':
                    this.executeMenuAction(event.data.action);
                    break;
                case 'get-menu-definition':
                    this.sendMenuDefinition();
                    break;
            }
        });

        console.log('[MinimalPlugin] 初期化完了');
    }

    handleInit(data) {
        if (data.fileData) {
            this.realId = data.fileData.realId;
            this.loadFile(data.fileData);
        }
    }

    loadFile(fileData) {
        if (fileData.xmlData) {
            // XMLをパース
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(fileData.xmlData, 'text/xml');

            // 内容を表示
            const contentElement = xmlDoc.querySelector('content');
            if (contentElement) {
                this.content = contentElement.textContent;
                document.getElementById('editor').textContent = this.content;
            }
        }
    }

    save() {
        // 内容を取得
        this.content = document.getElementById('editor').textContent;

        // XMLに変換
        const xmlData = `<?xml version="1.0" encoding="UTF-8"?>
<tad version="1.0">
    <content>${this.escapeXml(this.content)}</content>
</tad>`;

        // 親ウィンドウに通知
        window.parent.postMessage({
            type: 'xml-data-changed',
            realId: this.realId,
            xmlData: xmlData
        }, '*');

        console.log('[MinimalPlugin] 保存完了');
    }

    escapeXml(text) {
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&apos;');
    }

    sendMenuDefinition() {
        const menuDefinition = [
            {
                label: 'ファイル',
                submenu: [
                    { label: '保存', action: 'save', shortcut: 'Ctrl+S' },
                    { label: '閉じる', action: 'close' }
                ]
            }
        ];

        window.parent.postMessage({
            type: 'menu-definition',
            menuDefinition: menuDefinition
        }, '*');
    }

    executeMenuAction(action) {
        switch (action) {
            case 'save':
                this.save();
                break;
            case 'close':
                window.close();
                break;
        }
    }
}

// 初期化
document.addEventListener('DOMContentLoaded', () => {
    new MinimalPlugin();
});
```

### 仮身を扱うプラグイン

```javascript
// virtual-object-plugin/app.js
class VirtualObjectPlugin {
    constructor() {
        this.realId = null;
        this.virtualObjects = [];
        this.virtualObjectRenderer = null;
        this.init();
    }

    init() {
        // VirtualObjectRendererの初期化
        if (window.VirtualObjectRenderer) {
            this.virtualObjectRenderer = new window.VirtualObjectRenderer();
            console.log('[Plugin] VirtualObjectRenderer initialized');
        }

        // メッセージリスナー
        window.addEventListener('message', (event) => {
            if (!event.data) return;

            switch (event.data.type) {
                case 'init':
                    this.handleInit(event.data);
                    break;
                case 'drop-virtual-object':
                    this.handleVirtualObjectDrop(event.data);
                    break;
            }
        });

        // ドロップイベント
        this.setupDropZone();
    }

    setupDropZone() {
        const container = document.getElementById('container');

        container.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        });

        container.addEventListener('drop', async (e) => {
            e.preventDefault();

            const data = e.dataTransfer.getData('text/plain');
            if (data) {
                try {
                    const dragData = JSON.parse(data);

                    if (dragData.type === 'virtual-object-drag') {
                        const rect = container.getBoundingClientRect();
                        const x = e.clientX - rect.left;
                        const y = e.clientY - rect.top;

                        const virtualObjects = dragData.virtualObjects || [dragData.virtualObject];

                        virtualObjects.forEach((virtualObject) => {
                            this.addVirtualObject(x, y, virtualObject);
                        });

                        // クロスウィンドウドロップ成功を通知
                        window.parent.postMessage({
                            type: 'cross-window-drop-success',
                            mode: dragData.mode,
                            source: dragData.source,
                            sourceWindowId: dragData.sourceWindowId
                        }, '*');
                    }
                } catch (error) {
                    console.error('[Plugin] ドロップ処理エラー:', error);
                }
            }
        });
    }

    addVirtualObject(x, y, virtualObject) {
        // 仮身オブジェクトを追加
        this.virtualObjects.push({
            ...virtualObject,
            x: x,
            y: y
        });

        // 仮身をレンダリング
        const vobjElement = this.virtualObjectRenderer.render(virtualObject, {
            width: 150,
            height: 100
        });

        vobjElement.style.position = 'absolute';
        vobjElement.style.left = x + 'px';
        vobjElement.style.top = y + 'px';

        // ダブルクリックで開く
        vobjElement.addEventListener('dblclick', () => {
            this.openVirtualObject(virtualObject);
        });

        document.getElementById('container').appendChild(vobjElement);

        // 保存
        this.save();
    }

    openVirtualObject(virtualObject) {
        window.parent.postMessage({
            type: 'open-real-object',
            linkId: virtualObject.link_id,
            linkName: virtualObject.link_name,
            realId: virtualObject.link_id.replace(/_\d+\.xtad$/i, ''),
            pos: { x: 150, y: 150 }
        }, '*');
    }

    save() {
        // XMLデータを生成
        const xmlData = this.generateXML();

        // 親ウィンドウに通知
        window.parent.postMessage({
            type: 'xml-data-changed',
            realId: this.realId,
            xmlData: xmlData
        }, '*');
    }

    generateXML() {
        let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
        xml += '<tad version="1.0">\n';
        xml += '  <figure>\n';

        this.virtualObjects.forEach(vobj => {
            xml += `    <link id="${vobj.link_id}" x="${vobj.x}" y="${vobj.y}">${this.escapeXml(vobj.link_name)}</link>\n`;
        });

        xml += '  </figure>\n';
        xml += '</tad>\n';

        return xml;
    }

    escapeXml(text) {
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&apos;');
    }
}

// 初期化
document.addEventListener('DOMContentLoaded', () => {
    new VirtualObjectPlugin();
});
```

---

## デバッグ

### コンソールログ

プラグインのコンソールログは、開発者ツールで確認できます。

```javascript
// ログレベルを使い分ける
console.log('[Plugin] 通常のログ');
console.warn('[Plugin] 警告');
console.error('[Plugin] エラー');
console.debug('[Plugin] デバッグ情報');
```

### メッセージ通信のデバッグ

```javascript
// すべてのメッセージをログに出力
window.addEventListener('message', (event) => {
    console.log('[Plugin] メッセージ受信:', event.data);
});

// メッセージ送信をログに出力
const originalPostMessage = window.parent.postMessage;
window.parent.postMessage = function(message, targetOrigin) {
    console.log('[Plugin] メッセージ送信:', message);
    return originalPostMessage.call(this, message, targetOrigin);
};
```

---

## トラブルシューティング

### よくある問題

#### 1. メッセージが受信されない

- `window.addEventListener('message', ...)` が正しく設定されているか確認
- `event.data` が存在するか確認
- `event.data.type` が期待する値か確認

#### 2. ファイルが読み込めない

- `fileData.xmlData` が存在するか確認
- XMLのパースエラーがないか確認
- `realId` が正しく設定されているか確認

#### 3. 変更が保存されない

- `xml-data-changed` メッセージが正しく送信されているか確認
- `realId` が正しいか確認
- XMLデータが正しい形式か確認

#### 4. スクロールバーが表示されない

- `scroll-update` メッセージが送信されているか確認
- `scrollHeight`, `scrollWidth` が正しく計算されているか確認

---

## まとめ

このガイドでは、TADjs Desktopのプラグイン開発に必要な以下の要素について解説しました：

- プラグインの基本構造とフォルダ構成
- plugin.jsonの仕様
- 親ウィンドウとのメッセージ通信
- プラグインのライフサイクル
- 実身仮身システムとの連携
- メニューシステム
- 道具パネルの実装
- ベストプラクティスとデバッグ

実際のプラグイン開発では、既存のプラグイン（基本文章編集、仮身一覧、基本図形編集など）のソースコードを参考にすることをお勧めします。

## 参考リソース

- `plugins/basic-text-editor/` - 基本文章編集プラグイン
- `plugins/virtual-object-list/` - 仮身一覧プラグイン
- `plugins/basic-figure-editor/` - 基本図形編集プラグイン
- `js/virtual-object-renderer.js` - 仮身レンダラー
- `tadjs-desktop.js` - メインアプリケーション
