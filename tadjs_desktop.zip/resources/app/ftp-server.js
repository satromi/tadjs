const net = require('net');
const fs = require('fs');
const path = require('path');

const FTP_PORT = 2121;
const FTP_DATA_PORT = 2120;
const UPLOAD_DIR = path.join(__dirname, 'upload');

// Ensure upload directory exists
if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

class FTPSession {
    constructor(socket) {
        this.socket = socket;
        this.authenticated = false;
        this.username = null;
        this.currentDir = UPLOAD_DIR;
        this.dataSocket = null;
        this.dataServer = null;
        this.passiveMode = false;
        this.passivePort = null;
        this.transferType = 'A'; // ASCII by default
        this.renameFrom = null;
    }

    send(code, message) {
        try {
            if (this.socket && !this.socket.destroyed) {
                const response = `${code} ${message}\r\n`;
                console.log(`-> ${response.trim()}`);
                this.socket.write(response);
            }
        } catch (err) {
            console.error('Error sending response:', err.message);
        }
    }

    handleCommand(line) {
        const [cmd, ...args] = line.trim().split(' ');
        const arg = args.join(' ');
        const command = cmd.toUpperCase();

        console.log(`<- ${command} ${arg}`);

        switch (command) {
            case 'USER':
                this.handleUSER(arg);
                break;
            case 'PASS':
                this.handlePASS(arg);
                break;
            case 'SYST':
                this.send(215, 'UNIX Type: L8');
                break;
            case 'FEAT':
                this.send(211, 'Features:\r\n SIZE\r\n MDTM\r\n211 End');
                break;
            case 'PWD':
            case 'XPWD':
                this.handlePWD();
                break;
            case 'TYPE':
                this.handleTYPE(arg);
                break;
            case 'PASV':
                this.handlePASV();
                break;
            case 'PORT':
                this.handlePORT(arg);
                break;
            case 'LIST':
                this.handleLIST(arg);
                break;
            case 'NLST':
                this.handleNLST(arg);
                break;
            case 'RETR':
                this.handleRETR(arg);
                break;
            case 'STOR':
                this.handleSTOR(arg);
                break;
            case 'DELE':
                this.handleDELE(arg);
                break;
            case 'RMD':
            case 'XRMD':
                this.handleRMD(arg);
                break;
            case 'MKD':
            case 'XMKD':
                this.handleMKD(arg);
                break;
            case 'CWD':
            case 'XCWD':
                this.handleCWD(arg);
                break;
            case 'CDUP':
                this.handleCWD('..');
                break;
            case 'RNFR':
                this.handleRNFR(arg);
                break;
            case 'RNTO':
                this.handleRNTO(arg);
                break;
            case 'SIZE':
                this.handleSIZE(arg);
                break;
            case 'QUIT':
                this.send(221, 'Goodbye.');
                this.socket.end();
                break;
            case 'NOOP':
                this.send(200, 'OK');
                break;
            default:
                this.send(502, 'Command not implemented.');
        }
    }

    handleUSER(username) {
        this.username = username;
        this.send(331, 'Password required.');
    }

    handlePASS(password) {
        // Simple authentication - accept any password for demo
        // In production, implement proper authentication
        this.authenticated = true;
        this.send(230, 'User logged in.');
    }

    handlePWD() {
        const relPath = path.relative(UPLOAD_DIR, this.currentDir);
        const displayPath = relPath ? `/${relPath.replace(/\\/g, '/')}` : '/';
        this.send(257, `"${displayPath}" is current directory.`);
    }

    handleTYPE(type) {
        this.transferType = type.charAt(0).toUpperCase();
        this.send(200, `Type set to ${type}.`);
    }

    handlePASV() {
        this.passiveMode = true;
        const port = 3000 + Math.floor(Math.random() * 1000);
        this.passivePort = port;

        if (this.dataServer) {
            this.dataServer.close();
        }

        this.dataServer = net.createServer(socket => {
            this.dataSocket = socket;
        });

        this.dataServer.listen(port, '127.0.0.1', () => {
            const p1 = Math.floor(port / 256);
            const p2 = port % 256;
            this.send(227, `Entering Passive Mode (127,0,0,1,${p1},${p2}).`);
        });
    }

    handlePORT(arg) {
        this.passiveMode = false;
        const parts = arg.split(',');
        const ip = parts.slice(0, 4).join('.');
        const port = parseInt(parts[4]) * 256 + parseInt(parts[5]);

        this.dataSocket = new net.Socket();
        this.dataSocket.connect(port, ip, () => {
            this.send(200, 'PORT command successful.');
        });
    }

    handleLIST(arg) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        const listDir = arg ? path.join(this.currentDir, arg) : this.currentDir;

        fs.readdir(listDir, { withFileTypes: true }, (err, files) => {
            if (err) {
                this.send(550, 'Failed to list directory.');
                return;
            }

            this.send(150, 'Opening data connection.');

            const waitForDataSocket = () => {
                if (!this.dataSocket) {
                    setTimeout(waitForDataSocket, 100);
                    return;
                }

                let listing = '';
                files.forEach(file => {
                    const filePath = path.join(listDir, file.name);
                    try {
                        const stats = fs.statSync(filePath);
                        const isDir = stats.isDirectory();
                        const permissions = isDir ? 'drwxr-xr-x' : '-rw-r--r--';
                        const size = stats.size.toString().padStart(10, ' ');
                        const date = stats.mtime.toISOString().substr(0, 10);
                        listing += `${permissions} 1 user group ${size} ${date} ${file.name}\r\n`;
                    } catch (e) {
                        // Skip files we can't stat
                    }
                });

                this.dataSocket.write(listing);
                this.dataSocket.end();
                this.dataSocket = null;
                this.send(226, 'Transfer complete.');
            };

            waitForDataSocket();
        });
    }

    handleRETR(filename) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        const filePath = path.join(this.currentDir, filename);

        if (!filePath.startsWith(UPLOAD_DIR)) {
            this.send(550, 'Access denied.');
            return;
        }

        fs.readFile(filePath, (err, data) => {
            if (err) {
                this.send(550, 'File not found.');
                return;
            }

            this.send(150, 'Opening data connection.');

            const waitForDataSocket = () => {
                if (!this.dataSocket) {
                    setTimeout(waitForDataSocket, 100);
                    return;
                }

                try {
                    this.dataSocket.write(data);
                    this.dataSocket.end();
                    this.dataSocket = null;
                    this.send(226, 'Transfer complete.');
                } catch (err) {
                    console.error('Error during file transfer:', err.message);
                    this.send(426, 'Connection closed; transfer aborted.');
                    if (this.dataSocket) {
                        this.dataSocket.destroy();
                        this.dataSocket = null;
                    }
                }
            };

            waitForDataSocket();
        });
    }

    handleSTOR(filename) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        const filePath = path.join(this.currentDir, filename);

        if (!filePath.startsWith(UPLOAD_DIR)) {
            this.send(550, 'Access denied.');
            return;
        }

        this.send(150, 'Opening data connection.');

        const waitForDataSocket = () => {
            if (!this.dataSocket) {
                setTimeout(waitForDataSocket, 100);
                return;
            }

            const chunks = [];
            this.dataSocket.on('data', chunk => {
                chunks.push(chunk);
            });

            this.dataSocket.on('end', () => {
                const data = Buffer.concat(chunks);
                fs.writeFile(filePath, data, err => {
                    if (err) {
                        this.send(550, 'Failed to write file.');
                    } else {
                        this.send(226, 'Transfer complete.');
                    }
                });
                this.dataSocket = null;
            });

            this.dataSocket.on('error', err => {
                console.error('Data socket error:', err.message);
                this.send(426, 'Connection closed; transfer aborted.');
                this.dataSocket = null;
            });
        };

        waitForDataSocket();
    }

    handleDELE(filename) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        const filePath = path.join(this.currentDir, filename);

        if (!filePath.startsWith(UPLOAD_DIR)) {
            this.send(550, 'Access denied.');
            return;
        }

        fs.unlink(filePath, err => {
            if (err) {
                this.send(550, 'Failed to delete file.');
            } else {
                this.send(250, 'File deleted.');
            }
        });
    }

    handleRMD(dirname) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        const dirPath = path.join(this.currentDir, dirname);

        if (!dirPath.startsWith(UPLOAD_DIR)) {
            this.send(550, 'Access denied.');
            return;
        }

        fs.rmdir(dirPath, err => {
            if (err) {
                this.send(550, 'Failed to remove directory.');
            } else {
                this.send(250, 'Directory removed.');
            }
        });
    }

    handleMKD(dirname) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        const dirPath = path.join(this.currentDir, dirname);

        if (!dirPath.startsWith(UPLOAD_DIR)) {
            this.send(550, 'Access denied.');
            return;
        }

        fs.mkdir(dirPath, err => {
            if (err) {
                this.send(550, 'Failed to create directory.');
            } else {
                this.send(257, `"${dirname}" directory created.`);
            }
        });
    }

    handleCWD(dirname) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        // Handle root directory
        if (dirname === '/' || dirname === '//' || dirname === '') {
            this.currentDir = UPLOAD_DIR;
            this.send(250, 'Directory changed.');
            return;
        }

        // Remove leading slashes for relative path resolution
        const cleanDir = dirname.replace(/^\/+/, '');
        const newDir = cleanDir ? path.resolve(this.currentDir, cleanDir) : UPLOAD_DIR;

        // Ensure we stay within UPLOAD_DIR
        if (!newDir.startsWith(UPLOAD_DIR)) {
            this.currentDir = UPLOAD_DIR;
            this.send(250, 'Directory changed.');
            return;
        }

        fs.stat(newDir, (err, stats) => {
            if (err || !stats.isDirectory()) {
                this.send(550, 'Directory not found.');
            } else {
                this.currentDir = newDir;
                this.send(250, 'Directory changed.');
            }
        });
    }

    handleRNFR(filename) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        const filePath = path.join(this.currentDir, filename);

        if (!filePath.startsWith(UPLOAD_DIR)) {
            this.send(550, 'Access denied.');
            return;
        }

        fs.stat(filePath, err => {
            if (err) {
                this.send(550, 'File not found.');
            } else {
                this.renameFrom = filePath;
                this.send(350, 'Ready for RNTO.');
            }
        });
    }

    handleRNTO(filename) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        if (!this.renameFrom) {
            this.send(503, 'RNFR required first.');
            return;
        }

        const filePath = path.join(this.currentDir, filename);

        if (!filePath.startsWith(UPLOAD_DIR)) {
            this.send(550, 'Access denied.');
            return;
        }

        fs.rename(this.renameFrom, filePath, err => {
            if (err) {
                this.send(550, 'Rename failed.');
            } else {
                this.send(250, 'Rename successful.');
            }
            this.renameFrom = null;
        });
    }

    handleSIZE(filename) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        const filePath = path.join(this.currentDir, filename);

        if (!filePath.startsWith(UPLOAD_DIR)) {
            this.send(550, 'Access denied.');
            return;
        }

        fs.stat(filePath, (err, stats) => {
            if (err) {
                this.send(550, 'File not found.');
            } else {
                this.send(213, stats.size.toString());
            }
        });
    }

    handleNLST(arg) {
        if (!this.authenticated) {
            this.send(530, 'Not logged in.');
            return;
        }

        // Remove flags like -l, -1, etc.
        const cleanArg = arg ? arg.replace(/^-[a-zA-Z0-9]+\s*/, '') : '';
        const listDir = cleanArg ? path.join(this.currentDir, cleanArg) : this.currentDir;

        fs.readdir(listDir, (err, files) => {
            if (err) {
                this.send(550, 'Failed to list directory.');
                return;
            }

            this.send(150, 'Opening data connection.');

            const waitForDataSocket = () => {
                if (!this.dataSocket) {
                    setTimeout(waitForDataSocket, 100);
                    return;
                }

                let listing = files.join('\r\n');
                if (listing) {
                    listing += '\r\n';
                }

                this.dataSocket.write(listing);
                this.dataSocket.end();
                this.dataSocket = null;
                this.send(226, 'Transfer complete.');
            };

            waitForDataSocket();
        });
    }
}

const server = net.createServer(socket => {
    console.log(`FTP client connected from ${socket.remoteAddress}`);
    const session = new FTPSession(socket);

    // Handle socket errors
    socket.on('error', err => {
        console.error('FTP socket error:', err.message);
        if (session.dataServer) {
            session.dataServer.close();
        }
        if (session.dataSocket) {
            session.dataSocket.destroy();
            session.dataSocket = null;
        }
    });

    socket.on('close', () => {
        console.log('FTP client disconnected');
        if (session.dataServer) {
            session.dataServer.close();
        }
        if (session.dataSocket) {
            session.dataSocket.destroy();
            session.dataSocket = null;
        }
    });

    socket.on('end', () => {
        console.log('FTP client connection ended');
        if (session.dataServer) {
            session.dataServer.close();
        }
        if (session.dataSocket) {
            session.dataSocket.destroy();
            session.dataSocket = null;
        }
    });

    session.send(220, 'Simple FTP Server ready.');

    let buffer = '';
    socket.on('data', data => {
        try {
            buffer += data.toString();
            const lines = buffer.split('\r\n');
            buffer = lines.pop();

            lines.forEach(line => {
                if (line.trim()) {
                    session.handleCommand(line);
                }
            });
        } catch (err) {
            console.error('Error processing data:', err.message);
        }
    });
});

server.listen(FTP_PORT, () => {
    console.log(`FTP server listening on port ${FTP_PORT}`);
    console.log(`Upload directory: ${UPLOAD_DIR}`);
    console.log('\nTo connect:');
    console.log('  ftp localhost 2121');
    console.log('  Username: any');
    console.log('  Password: any');
});