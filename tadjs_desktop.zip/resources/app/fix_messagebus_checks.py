#!/usr/bin/env python3
import re

# ファイルを読み込む
with open('tadjs-desktop.js', 'r', encoding='utf-8') as f:
    content = f.read()

# パターン1: if (this.parentMessageBus) { ... } else { console.warn(...) }
# respondToのパターン
pattern1 = r'if \(this\.parentMessageBus\) \{\s*this\.parentMessageBus\.respondTo\(([^\}]+)\);\s*\} else \{\s*console\.warn\([^\)]+\);\s*\}'
replacement1 = r'this.parentMessageBus.respondTo(\1);'

# パターン2: 単純なif (this.parentMessageBus) { メソッド呼び出し } (elseなし)
pattern2 = r'if \(this\.parentMessageBus\) \{\s*this\.parentMessageBus\.(registerChild|unregisterChild|sendToWindow|broadcast|respondTo)\('
replacement2 = r'this.parentMessageBus.\1('

# パターン3: console.warn('[TADjs] MessageBus未初期化: ...')を削除
pattern3 = r'\s*\} else \{\s*console\.warn\(\'\[TADjs\] MessageBus未初期化:[^\']+\'\);\s*\}'
replacement3 = ''

# 置換実行
content = re.sub(pattern1, replacement1, content, flags=re.MULTILINE | re.DOTALL)
# content = re.sub(pattern2, replacement2, content)
# content = re.sub(pattern3, replacement3, content)

# ファイルに書き込む
with open('tadjs-desktop.js', 'w', encoding='utf-8') as f:
    f.write(content)

print("置換完了")
