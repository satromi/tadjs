// JavaScript Document

function check000( flag )
{
   if( flag == 00 )
   {
			var kantonClass = document.getElementById('kanton').className ;
      if( kantonClass == "on" )
			{
					document.getElementById('kanton').className = "off" ;
					document.getElementById('box0').replace(/checked/g,'unchecked') ;
			}
			if( kantonClass == "off" )
			{
					document.getElementById('kanton').className = "on" ;
					document.getElementById('box0').replace(/unchecked/g,'checked') ;
			}
   }
   if( flag == 01 )
   {
			var pekinClass = document.getElementById('pekin').className ;
      if( pekinClass == "on" )
			{
					document.getElementById('pekin').className = "off" ;
					document.getElementById('box1').replace(/checked/g,'uncheck') ;
			}
			if( pekinClass == "off" ) {
					document.getElementById('pekin').className = "on" ;
					document.getElementById('box1').replace(/unchecked/g,'checked') ;
			}
   }
   if( flag == 02 )
   {
			var shisenClass = document.getElementById('shisen').className ;
      if( shisenClass == "on" )
			{
					document.getElementById('shisen').className = "off" ;
					document.getElementById('box2').replace(/checked/g,'uncheck') ;
			}
			if( shisenClass == "off" ) {
					document.getElementById('shisen').className = "on" ;
					document.getElementById('box2').replace(/unchecked/g,'checked') ;
			}
   }
	 if( flag == 03 )
   		{
   var syanhaiClass = document.getElementById('syanhai').className ;
      if( syanhaiClass == "on" )
			{
					document.getElementById('syanhai').className = "off" ;
					document.getElementById('box3').replace(/checked/g,'uncheck') ;
			}
			if( syanhaiClass == "off" ) {
					document.getElementById('syanhai').className = "on" ;
					document.getElementById('box3').replace(/unchecked/g,'checked') ;
			}
   }
	 if( flag == 04 )
   		{
   var yamuchaClass = document.getElementById('yamucha').className ;
      if( yamuchaClass == "on" )
			{
					document.getElementById('yamucha').className = "off" ;
					document.getElementById('box4').replace(/checked/g,'uncheck') ;
			}
			if( yamuchaClass == "off" ) {
					document.getElementById('yamucha').className = "on" ;
					document.getElementById('box4').replace(/unchecked/g,'checked') ;
			}
   }
	 if( flag == 05 )
   		{
   var sonotaClass = document.getElementById('sonota').className ;
      if( sonotaClass == "on" )
			{
					document.getElementById('sonota').className = "off" ;
					document.getElementById('box5').replace(/checked/g,'uncheck') ;
			}
			if( sonotaClass == "off" ) {
					document.getElementById('sonota').className = "on" ;
					document.getElementById('box5').replace(/unchecked/g,'checked') ;
			}
   }
}
